-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 01, 2014 at 08:14 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `veritas`
--

-- --------------------------------------------------------

--
-- Table structure for table `activities`
--

CREATE TABLE IF NOT EXISTS `activities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `document_id` int(11) NOT NULL,
  `time` time NOT NULL,
  `date` date NOT NULL,
  `desc` varchar(255) NOT NULL,
  `addedBy` int(11) NOT NULL DEFAULT '0',
  `report_type` int(11) NOT NULL COMMENT '1=>activitylog, 2=>mobile inspection, 3=>mobile security, 4=>security occurance, 5=>Incident Report, 6=>Sign-off Sheet',
  `incident_type` varchar(255) NOT NULL,
  `uploaded_on` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=48 ;

--
-- Dumping data for table `activities`
--

INSERT INTO `activities` (`id`, `document_id`, `time`, `date`, `desc`, `addedBy`, `report_type`, `incident_type`, `uploaded_on`) VALUES
(2, 24, '21:25:00', '2013-08-29', 'asdasdas1', 0, 5, 'Fraud Apprehension', '0000-00-00'),
(3, 25, '21:58:00', '2013-08-29', 'adfadfad', 0, 5, 'Alarm Activation', '0000-00-00'),
(4, 26, '22:53:00', '2013-08-29', 'adsfadfad', 0, 5, 'Burglary', '0000-00-00'),
(5, 27, '23:37:00', '2013-08-29', 'sfgsfgsfdg', 0, 5, 'Miscellaneous', '0000-00-00'),
(7, 30, '00:33:00', '2013-08-30', 'adfadfadf', 0, 5, 'Alarm Activation', '0000-00-00'),
(8, 31, '00:34:00', '2013-08-30', 'adfadf', 0, 5, 'Alarm Activation', '0000-00-00'),
(9, 32, '00:35:00', '2013-08-30', 'hjgjhgjhgjh', 0, 5, 'Property Damage', '0000-00-00'),
(10, 33, '00:41:00', '2013-08-30', 'hjgjhgjhgjh', 0, 5, 'Burglary', '0000-00-00'),
(11, 34, '21:47:00', '2013-09-03', 'adsfadfadsfadsf', 0, 5, 'Fraud Recovery', '0000-00-00'),
(12, 35, '21:53:00', '2013-09-03', 'adsfadfadsfadsf', 0, 5, 'Fraud Recovery', '0000-00-00'),
(13, 36, '21:53:00', '2013-09-03', 'adsfadfadsfadsf', 0, 5, 'Fraud Recovery', '0000-00-00'),
(14, 37, '20:56:00', '2013-09-04', 'adfadfad', 0, 5, 'Alarm Activation', '0000-00-00'),
(15, 38, '21:04:00', '2013-09-04', 'adfadfa', 0, 5, 'Shoplift Recovery', '0000-00-00'),
(16, 39, '21:32:00', '2013-09-04', 'adfadsf', 0, 1, '', '0000-00-00'),
(17, 40, '22:24:00', '2013-09-04', 'adxfadfadf', 0, 5, 'Miscellaneous', '0000-00-00'),
(18, 41, '22:28:00', '2013-09-04', 'adfadfa', 0, 1, '', '0000-00-00'),
(19, 42, '22:28:00', '2013-09-04', 'adfadfa', 0, 1, '', '0000-00-00'),
(20, 43, '21:13:00', '2013-09-10', 'asdasd', 0, 2, '', '0000-00-00'),
(21, 43, '21:13:00', '2013-09-10', 'kkkktwetesting', 0, 2, '', '0000-00-00'),
(22, 44, '21:36:00', '2013-09-10', 'asdasd', 0, 2, '', '0000-00-00'),
(23, 44, '21:37:00', '2013-09-10', 'asdasdasd', 0, 2, '', '0000-00-00'),
(30, 46, '21:46:00', '2013-09-10', 'aaaaa', 0, 1, '', '0000-00-00'),
(31, 46, '21:46:00', '2013-09-10', 'llkmalkslasdte', 0, 1, '', '0000-00-00'),
(32, 45, '21:41:00', '2013-09-10', 'asdasd', 0, 5, 'Disorderly Person', '0000-00-00'),
(33, 45, '21:41:00', '2013-09-10', 'oiuouoii', 0, 5, 'Disorderly Person', '0000-00-00'),
(34, 49, '03:27:00', '2013-09-11', 'asdasd', 0, 2, '', '0000-00-00'),
(35, 49, '03:27:00', '2013-09-06', 'asdas', 0, 6, '', '0000-00-00'),
(36, 49, '03:28:00', '2013-09-11', 'asdasd', 0, 2, '', '0000-00-00'),
(39, 50, '19:46:00', '2013-09-11', '1', 0, 5, 'Burglary', '0000-00-00'),
(40, 50, '19:46:00', '2013-09-11', '2', 0, 5, 'Burglary', '0000-00-00'),
(41, 60, '21:50:00', '2013-09-24', 'asdas asdasda sdasd asdasdasd', 3, 6, '', '0000-00-00'),
(42, 28, '21:58:00', '2013-09-24', 'sfgsfgsfdg', 3, 5, 'Miscellaneous', '0000-00-00'),
(43, 70, '06:49:00', '2013-10-11', 'asdasd', 0, 7, '', '0000-00-00'),
(47, 93, '21:01:00', '2013-10-16', '', 0, 7, '', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `additional_infos`
--

CREATE TABLE IF NOT EXISTS `additional_infos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `doc_id` int(11) NOT NULL,
  `orc` varchar(255) NOT NULL,
  `force` varchar(255) NOT NULL,
  `shoplift` varchar(255) NOT NULL,
  `weapon_used` varchar(255) NOT NULL,
  `narrative` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `additional_infos`
--

INSERT INTO `additional_infos` (`id`, `doc_id`, `orc`, `force`, `shoplift`, `weapon_used`, `narrative`) VALUES
(1, 91, 'no', 'no', 'no', 'no', '\r\nsd;lfkg;lsdfkg;lsdfkg\r\n\r\n''dfgkd;lfkg;ldfkg;ldfg\r\nd;lfkg;ldfkg;ldkfgdfg;fdgk;dlfgkdf''g\r\n\r\ndflgkd;flgk;dlfkg;dlfkmc;vl mvc.,mb.,cvmb.,fcmb;lkl;sd;lfjgnsdfg\r\n;lds;flgj;lsdfjg;lsdfjgd;lfgja;'';a\r\nlllslkdjnflkanajsdlkfnaklsndflkandglkadnflgad\r\naSdddddddddssssssssssss as.;/,msd/.gsdakm;lg sjfd;glksdf''sdkfgsfd\\fsdkgsd;lfg'),
(2, 92, 'no', 'no', 'no', 'no', '\r\nsd;lfkg;lsdfkg;lsdfkg\r\n\r\n''dfgkd;lfkg;ldfkg;ldfg\r\nd;lfkg;ldfkg;ldkfgdfg;fdgk;dlfgkdf''g\r\n\r\ndflgkd;flgk;dlfkg;dlfkmc;vl mvc.,mb.,cvmb.,fcmb;lkl;sd;lfjgnsdfg\r\n;lds;flgj;lsdfjg;lsdfjgd;lfgja;'';a\r\nlllslkdjnflkanajsdlkfnaklsndflkandglkadnflgad\r\naSdddddddddssssssssssss as.;/,msd/.gsdakm;lg sjfd;glksdf''sdkfgsfd\\fsdkgsd;lfg'),
(6, 93, 'no', 'no', 'no', 'no', '111 ALKSDJLKASDFJ ASODIFU AOISDF JAOISDFJ SJWHAT TH AOKSJHDA OSDIA SIDJ OISJOI DIFUCKJH]]ASDKLHJA SLKDJHF JADSHF AOIUDS HIUASDFJJAJasas[pasdkfapksdjf  asshiole [as'' dkfpsd fpoasdjfpjkbadnfijghaodbgadkmnvkdmnvcakjdfbjaidbajdkfvbadjfvbaijdfvijdav\r\nasdakljaoka  SI KNCOIW TR WHATA HT E HELL U BNWNAU \r\n''asllsll sld jfohile fuyckjk ha [a[ask fhelkl askha s[a sniuvbhshias][kkdfhgv sdlkfng ksiahskjksldfkjas dfkjasbdhfkj hasdoijgh \r\n[LKJSHDKFJS F   ');

-- --------------------------------------------------------

--
-- Table structure for table `admin_docs`
--

CREATE TABLE IF NOT EXISTS `admin_docs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contracts` int(11) NOT NULL,
  `evidence` int(11) NOT NULL,
  `templates` int(11) NOT NULL,
  `report` int(11) NOT NULL,
  `site_orders` int(11) NOT NULL,
  `training` int(11) NOT NULL,
  `employee` int(11) NOT NULL,
  `kpiaudits` int(11) NOT NULL,
  `afimac_intel` int(11) NOT NULL,
  `news_media` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin_docs`
--

INSERT INTO `admin_docs` (`id`, `contracts`, `evidence`, `templates`, `report`, `site_orders`, `training`, `employee`, `kpiaudits`, `afimac_intel`, `news_media`) VALUES
(1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `canuploads`
--

CREATE TABLE IF NOT EXISTS `canuploads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL,
  `contracts` int(11) NOT NULL,
  `evidence` int(11) NOT NULL,
  `templates` int(11) NOT NULL,
  `report` int(11) NOT NULL,
  `client_feedback` int(11) NOT NULL,
  `siteOrder` int(11) NOT NULL,
  `training` int(11) NOT NULL,
  `employee` int(11) NOT NULL,
  `KPIAudits` int(11) NOT NULL,
  `afimac_intel` int(11) NOT NULL,
  `news_media` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=40 ;

--
-- Dumping data for table `canuploads`
--

INSERT INTO `canuploads` (`id`, `member_id`, `contracts`, `evidence`, `templates`, `report`, `client_feedback`, `siteOrder`, `training`, `employee`, `KPIAudits`, `afimac_intel`, `news_media`) VALUES
(2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0),
(5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0),
(7, 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0),
(8, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0),
(14, 7, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0),
(26, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1),
(29, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1),
(38, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1),
(39, 3, 1, 1, 0, 1, 1, 1, 1, 1, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `canviews`
--

CREATE TABLE IF NOT EXISTS `canviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL,
  `contracts` int(11) NOT NULL,
  `evidence` int(11) NOT NULL,
  `templates` int(11) NOT NULL,
  `report` int(11) NOT NULL,
  `siteOrder` int(11) NOT NULL,
  `training` int(11) NOT NULL,
  `employee` int(11) NOT NULL,
  `KPIAudits` int(11) NOT NULL,
  `client_feedback` int(11) NOT NULL,
  `afimac_intel` int(11) NOT NULL,
  `news_media` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=45 ;

--
-- Dumping data for table `canviews`
--

INSERT INTO `canviews` (`id`, `member_id`, `contracts`, `evidence`, `templates`, `report`, `siteOrder`, `training`, `employee`, `KPIAudits`, `client_feedback`, `afimac_intel`, `news_media`) VALUES
(2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0),
(5, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0),
(7, 4, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0),
(8, 5, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0),
(14, 7, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0),
(26, 9, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1),
(34, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1),
(43, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1),
(44, 3, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `clientmemos`
--

CREATE TABLE IF NOT EXISTS `clientmemos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `document_id` int(11) NOT NULL,
  `time` time NOT NULL,
  `date` date NOT NULL,
  `memo_type` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `clientmemos`
--

INSERT INTO `clientmemos` (`id`, `document_id`, `time`, `date`, `memo_type`, `guard_name`) VALUES
(1, 5, '00:48:00', '2013-07-06', 'feedback', 'adfa'),
(2, 16, '20:28:00', '2013-07-24', 'observation', 'akdjfhad');

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE IF NOT EXISTS `companies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `no_of_worker` int(11) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `companies`
--


-- --------------------------------------------------------

--
-- Table structure for table `docs`
--

CREATE TABLE IF NOT EXISTS `docs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `document_id` int(11) NOT NULL,
  `doc` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `docs`
--

INSERT INTO `docs` (`id`, `document_id`, `doc`) VALUES
(1, 1, 'Contract_akjsdfh_ak_2013-07-05_16-48-14.txt'),
(2, 3, 'Contract_jasdfh_akj_2013-07-05_16-51-39.txt'),
(3, 27, ''),
(4, 28, ''),
(5, 30, ''),
(6, 34, ''),
(7, 35, ''),
(8, 36, ''),
(9, 39, ''),
(10, 40, ''),
(11, 42, 'Report_activityLog_2013-09-04_16-44-37.txt'),
(12, 94, 'Template_2013-10-23_14-15-33.csv'),
(13, 97, 'Template_2013-10-23_14-27-45.xlsx'),
(14, 98, 'Contract_2013-10-23_14-37-08.xls'),
(15, 99, 'Contract_2013-10-23_14-54-01.xls'),
(16, 100, 'Contract_2013-10-23_18-36-10.xls'),
(17, 101, 'Contract_2013-10-23_18-39-06.xls');

-- --------------------------------------------------------

--
-- Table structure for table `documents`
--

CREATE TABLE IF NOT EXISTS `documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `location` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `document_type` varchar(255) NOT NULL,
  `evidence_type` varchar(255) NOT NULL,
  `evidence_author` varchar(255) NOT NULL,
  `training_type` varchar(255) NOT NULL,
  `site_type` varchar(255) NOT NULL,
  `employee_type` varchar(255) NOT NULL,
  `incident_date` date NOT NULL,
  `client_feedback` longtext NOT NULL,
  `date` datetime NOT NULL,
  `addedBy` int(11) NOT NULL,
  `job_id` int(11) NOT NULL,
  `job_title` varchar(255) NOT NULL,
  `draft` int(11) NOT NULL DEFAULT '0' COMMENT '0=>non draft ,1=>is draft',
  `indate` datetime NOT NULL,
  `test` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=110 ;

--
-- Dumping data for table `documents`
--

INSERT INTO `documents` (`id`, `location`, `title`, `description`, `document_type`, `evidence_type`, `evidence_author`, `training_type`, `site_type`, `employee_type`, `incident_date`, `client_feedback`, `date`, `addedBy`, `job_id`, `job_title`, `draft`, `indate`, `test`) VALUES
(1, '', 'Contract', 'akjsdfh akjfh akjsfd hasjkdfh aksjdf', 'contract', '', '', '', '', '', '0000-00-00', '', '2013-07-05 16:47:52', 0, 1, 'job1111', 0, '2013-07-05 16:47:52', '0000-00-00 00:00:00'),
(2, '', 'Contract', 'asdhf asjkdhf aksjdhf kajsd fhkjh', 'contract', '', '', '', '', '', '0000-00-00', '', '2013-07-05 16:49:34', 0, 1, 'job1111', 0, '2013-07-05 16:49:34', '0000-00-00 00:00:00'),
(3, '', 'Contract', 'jasdfh akjdf haksjdf haksjdhf aksjd hf', 'contract', '', '', '', '', '', '0000-00-00', '', '2013-07-05 16:51:29', 1, 1, 'job1111', 0, '2013-07-05 16:51:29', '0000-00-00 00:00:00'),
(4, '', 'Evidence', 'jhgv jhg jhg hjg jhg', 'evidence', 'Incident Report', '', '', '', '', '2013-07-06', '', '2013-07-05 18:42:28', 1, 1, 'job1111', 0, '2013-07-06 00:00:00', '0000-00-00 00:00:00'),
(5, '', 'Client feedback', 'adklf adlfaj dlfkjadlkfj ', 'client_feedback', '', '', '', '', '', '0000-00-00', '', '2013-07-05 19:04:06', 2, 1, 'job1111', 0, '2013-07-05 19:04:06', '0000-00-00 00:00:00'),
(6, '', 'Contract', 'adkfja dfa lkfj la', 'contract', '', '', '', '', '', '0000-00-00', '', '2013-07-05 20:13:35', 2, 1, 'job1111', 0, '2013-07-05 20:13:35', '0000-00-00 00:00:00'),
(7, '', 'Evidence', 'akjdfh adjkfha kdjfhakdjfha kdjfh askdjfh', 'evidence', 'Incident Report', '', '', '', '', '2013-07-22', '', '2013-07-22 17:55:08', 0, 1, 'job1111', 0, '2013-07-22 00:00:00', '0000-00-00 00:00:00'),
(8, '', 'Evidence', 'akjdfh adjkfha kdjfhakdjfha kdjfh askdjfh', 'evidence', 'Incident Report', '', '', '', '', '2013-07-22', '', '2013-07-22 17:57:06', 0, 1, 'job1111', 0, '2013-07-22 00:00:00', '0000-00-00 00:00:00'),
(9, '', 'Evidence', 'akjdfh adjkfha kdjfhakdjfha kdjfh askdjfh', 'evidence', 'Incident Report', '', '', '', '', '2013-07-22', '', '2013-07-22 17:58:24', 0, 1, 'job1111', 0, '2013-07-22 00:00:00', '0000-00-00 00:00:00'),
(10, '', 'Evidence', 'akjdfh adjkfha kdjfhakdjfha kdjfh askdjfh', 'evidence', 'Incident Report', '', '', '', '', '2013-07-22', '', '2013-07-22 17:58:32', 0, 1, 'job1111', 0, '2013-07-22 00:00:00', '0000-00-00 00:00:00'),
(11, '', 'Evidence', 'akjdfh adjkfha kdjfhakdjfha kdjfh askdjfh', 'evidence', 'Incident Report', '', '', '', '', '2013-07-22', '', '2013-07-22 17:59:38', 0, 1, 'job1111', 0, '2013-07-22 00:00:00', '0000-00-00 00:00:00'),
(12, '', 'Evidence', 'akjdfh adjkfha kdjfhakdjfha kdjfh askdjfh', 'evidence', 'Incident Report', '', '', '', '', '2013-07-22', '', '2013-07-22 18:00:09', 0, 1, 'job1111', 0, '2013-07-22 00:00:00', '0000-00-00 00:00:00'),
(13, '', 'Evidence', 'akjdfh adjkfha kdjfhakdjfha kdjfh askdjfh', 'evidence', 'Incident Report', '', '', '', '', '2013-07-22', '', '2013-07-22 18:01:29', 0, 1, 'job1111', 0, '2013-07-22 00:00:00', '0000-00-00 00:00:00'),
(14, '', 'Evidence', 'akjdfh adjkfha kdjfhakdjfha kdjfh askdjfh', 'evidence', 'Incident Report', '', '', '', '', '2013-07-22', '', '2013-07-22 18:02:37', 0, 1, 'job1111', 0, '2013-07-22 00:00:00', '0000-00-00 00:00:00'),
(15, '', 'Contract', 'alkdjf adkfja dlkfj a', 'contract', '', '', '', '', '', '0000-00-00', '', '2013-07-22 18:03:24', 0, 1, 'job1111', 0, '2013-07-22 18:03:24', '0000-00-00 00:00:00'),
(16, '', 'Client feedback', 'sample description', 'client_feedback', '', '', '', '', '', '0000-00-00', '', '2013-07-24 14:43:32', 3, 1, 'job1111', 0, '2013-07-24 14:43:32', '0000-00-00 00:00:00'),
(17, '', 'Report', ' adsfadf asdf adsfa dfad fadfasdfadf ', 'report', '', '', '', '', '', '0000-00-00', '', '2013-07-29 17:23:57', 0, 1, 'job1111', 0, '2013-07-29 17:23:57', '0000-00-00 00:00:00'),
(18, '', 'Report', 'Testing now', 'report', '', '', '', '', '', '0000-00-00', '', '2013-07-29 17:31:00', 0, 1, 'job1111', 0, '2013-07-29 17:31:00', '0000-00-00 00:00:00'),
(19, '', 'Report', 'asdasdasda', 'report', '', '', '', '', '', '0000-00-00', '', '2013-08-29 15:38:55', 3, 1, 'job1111', 1, '2013-08-29 15:38:55', '0000-00-00 00:00:00'),
(20, '', 'Report', 'asdasdasda', 'report', '', '', '', '', '', '0000-00-00', '', '2013-08-29 15:39:13', 3, 1, 'job1111', 1, '2013-08-29 15:39:13', '0000-00-00 00:00:00'),
(21, '', 'Report', 'asdasdas', 'report', '', '', '', '', '', '0000-00-00', '', '2013-08-29 15:40:25', 3, 1, 'job1111', 0, '2013-08-29 15:40:25', '0000-00-00 00:00:00'),
(22, '', 'Report', 'asdasdas', 'report', '', '', '', '', '', '0000-00-00', '', '2013-08-29 15:44:01', 3, 1, 'job1111', 0, '2013-08-29 15:44:01', '0000-00-00 00:00:00'),
(23, '', 'Report', 'asdasdas', 'report', '', '', '', '', '', '0000-00-00', '', '2013-08-29 15:44:37', 3, 1, 'job1111', 0, '2013-08-29 15:44:37', '0000-00-00 00:00:00'),
(24, '', 'Report', 'asdasdas', 'report', '', '', '', '', '', '0000-00-00', '', '2013-08-29 15:47:09', 3, 1, 'job1111', 0, '2013-08-29 15:47:09', '0000-00-00 00:00:00'),
(25, '', 'Report', 'adfadfasdfadf', 'report', '', '', '', '', '', '0000-00-00', '', '2013-08-29 16:14:58', 3, 1, 'job1111', 0, '2013-08-29 16:14:58', '0000-00-00 00:00:00'),
(26, '', 'Report', '', 'report', '', '', '', '', '', '0000-00-00', '', '2013-08-29 17:50:35', 3, 1, 'job1111', 0, '2013-08-29 17:50:35', '0000-00-00 00:00:00'),
(27, '', 'Report', 'uhygjhgjhgjhg', 'report', '', '', '', '', '', '0000-00-00', '', '2013-08-29 17:53:32', 3, 1, 'job1111', 0, '2013-08-29 17:53:32', '0000-00-00 00:00:00'),
(28, '', 'Report', 'uhygjhgjhgjhg', 'report', '', '', '', '', '', '0000-00-00', '', '2013-09-24 16:13:29', 3, 1, 'job1111', 0, '2013-08-29 18:09:15', '0000-00-00 00:00:00'),
(29, '', 'Report', 'adfadf', 'report', '', '', '', '', '', '0000-00-00', '', '2013-08-29 18:48:47', 3, 1, 'job1111', 0, '2013-08-29 18:48:47', '0000-00-00 00:00:00'),
(30, '', 'Report', 'adfadf', 'report', '', '', '', '', '', '0000-00-00', '', '2013-08-29 18:49:25', 3, 1, 'job1111', 0, '2013-08-29 18:49:25', '0000-00-00 00:00:00'),
(31, '', 'Report', 'adfadfadf', 'report', '', '', '', '', '', '0000-00-00', '', '2013-08-29 18:50:14', 3, 1, 'job1111', 0, '2013-08-29 18:50:14', '0000-00-00 00:00:00'),
(32, '', 'Report', '', 'report', '', '', '', '', '', '0000-00-00', '', '2013-08-29 18:52:25', 3, 1, 'job1111', 0, '2013-08-29 18:52:25', '0000-00-00 00:00:00'),
(33, '', 'Report', 'adfadf', 'report', '', '', '', '', '', '0000-00-00', '', '2013-08-29 18:56:36', 3, 1, 'job1111', 0, '2013-08-29 18:56:36', '0000-00-00 00:00:00'),
(34, '', 'Report', 'adfadsfadf', 'report', '', '', '', '', '', '0000-00-00', '', '2013-09-03 16:03:45', 0, 1, 'job1111', 0, '2013-09-03 16:03:45', '0000-00-00 00:00:00'),
(35, '', 'Report', 'adfadsfadf', 'report', '', '', '', '', '', '0000-00-00', '', '2013-09-03 16:08:31', 0, 1, 'job1111', 0, '2013-09-03 16:08:31', '0000-00-00 00:00:00'),
(36, '', 'Report', 'adfadsfadf', 'report', '', '', '', '', '', '0000-00-00', '', '2013-09-03 16:14:32', 0, 1, 'job1111', 0, '2013-09-03 16:14:32', '0000-00-00 00:00:00'),
(37, '', 'Report', 'adfadf', 'report', '', '', '', '', '', '0000-00-00', '', '2013-09-04 15:11:45', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(38, '', 'Report', 'adfadf', 'report', '', '', '', '', '', '0000-00-00', '', '2013-09-04 15:19:56', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(39, '', 'Report', 'adfadf', 'report', '', '', '', '', '', '0000-00-00', '', '2013-09-04 15:48:17', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(40, '', 'Report', 'adfadfadf', 'report', '', '', '', '', '', '0000-00-00', '', '2013-09-04 16:40:07', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(41, '', 'Report', 'adfadf', 'report', '', '', '', '', '', '0000-00-00', '', '2013-09-04 16:44:08', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(42, '', 'Report', 'adfadf', 'report', '', '', '', '', '', '0000-00-00', '', '2013-09-04 16:44:36', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(43, '', 'Report', 'asdasd asdasd', 'report', '', '', '', '', '', '0000-00-00', '', '2013-09-10 15:29:10', 3, 1, 'job1111', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(44, '', 'Report', 'asdasdasd', 'report', '', '', '', '', '', '0000-00-00', '', '2013-09-10 15:52:16', 3, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(45, '', 'Report', 'asdasdasd asdasd', 'report', '', '', '', '', '', '0000-00-00', '', '2013-09-10 16:10:36', 3, 3, 'job 3', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(46, '', 'Report', 'testing', 'report', '', '', '', '', '', '0000-00-00', '', '2013-09-10 16:08:47', 3, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(47, '', 'Evidence', 'asdasda asdasdasdasd asdasd', 'evidence', 'Line Crossing Sheet', '', '', '', '', '2013-09-03', '', '2013-09-10 21:16:32', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(48, '', 'Evidence', 'asdasda asdasdasdasd asdasd', 'evidence', 'Line Crossing Sheet', '', '', '', '', '2013-09-03', '', '2013-09-10 21:22:43', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(49, '', 'Report', 'asdasd', 'report', '', '', '', '', '', '0000-00-00', '', '2013-09-10 21:43:35', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(50, '', 'Report', '333333', 'report', '', '', '', '', '', '0000-00-00', '', '2013-09-11 14:02:32', 3, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(51, '', 'Evidence', 'kjkjkj', 'evidence', 'Incident Report', '', '', '', '', '2013-09-10', '', '2013-09-11 16:17:28', 0, 2, 'job2', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(52, '', 'Contract', 'Testing', 'contract', '', '', '', '', '', '0000-00-00', '', '2013-09-23 16:48:08', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(53, '', 'Contract', 'Test document', 'contract', '', '', '', '', '', '0000-00-00', '', '2013-09-23 16:54:04', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(54, '', 'Contract', 'adfad', 'contract', '', '', '', '', '', '0000-00-00', '', '2013-09-23 16:58:07', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(55, '', 'Contract', 'adfadf', 'contract', '', '', '', '', '', '0000-00-00', '', '2013-09-23 17:01:50', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(56, '', 'Contract', 'adfad', 'contract', '', '', '', '', '', '0000-00-00', '', '2013-09-23 17:04:54', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(57, '', 'Contract', 'adfad', 'contract', '', '', '', '', '', '0000-00-00', '', '2013-09-23 17:06:20', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(58, '', 'Contract', 'adfad', 'contract', '', '', '', '', '', '0000-00-00', '', '2013-09-23 17:07:06', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(59, '', 'Contract', 'adfadf', 'contract', '', '', '', '', '', '0000-00-00', '', '2013-09-23 17:08:20', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(60, '', 'Report', 'asd asdas dasdasd asdasd', 'report', '', '', '', '', '', '0000-00-00', '', '2013-09-24 16:06:22', 3, 8, 'new', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(61, '', 'Template', 'asdas asdas1', 'template', '', '', '', '', '', '0000-00-00', '', '2013-10-23 14:08:43', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(62, '', 'Report', 'asdasd', 'report', '', '', '', '', '', '0000-00-00', '', '2013-10-10 18:47:32', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(63, '', 'Report', '', 'report', '', '', '', '', '', '0000-00-00', '', '2013-10-10 18:52:05', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(64, '', 'Report', '', 'report', '', '', '', '', '', '0000-00-00', '', '2013-10-10 19:01:11', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(65, '', 'Report', '', 'report', '', '', '', '', '', '0000-00-00', '', '2013-10-10 19:03:09', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(66, '', 'Report', '', 'report', '', '', '', '', '', '0000-00-00', '', '2013-10-10 19:04:56', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(67, '', 'Report', '', 'report', '', '', '', '', '', '0000-00-00', '', '2013-10-10 19:06:50', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(68, '', 'Report', '', 'report', '', '', '', '', '', '0000-00-00', '', '2013-10-10 19:10:45', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(69, '', 'Report', '', 'report', '', '', '', '', '', '0000-00-00', '', '2013-10-11 01:05:46', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(70, '', 'Report', '', 'report', '', '', '', '', '', '0000-00-00', '', '2013-10-11 01:10:12', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(71, '', 'Report', '', 'report', '', '', '', '', '', '0000-00-00', '', '2013-10-11 01:12:19', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(72, '', 'Report', '', 'report', '', '', '', '', '', '0000-00-00', '', '2013-10-11 01:13:54', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(73, '', 'Report', '', 'report', '', '', '', '', '', '0000-00-00', '', '2013-10-11 01:16:45', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(74, '', 'Report', '', 'report', '', '', '', '', '', '0000-00-00', '', '2013-10-11 01:19:18', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(75, '', 'Report', '', 'report', '', '', '', '', '', '0000-00-00', '', '2013-10-11 01:22:06', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(76, '', 'Report', '', 'report', '', '', '', '', '', '0000-00-00', '', '2013-10-11 01:25:00', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(77, '', 'Report', '', 'report', '', '', '', '', '', '0000-00-00', '', '2013-10-11 01:29:14', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(78, '', 'Report', '', 'report', '', '', '', '', '', '0000-00-00', '', '2013-10-11 01:30:51', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(79, '', 'Report', '', 'report', '', '', '', '', '', '0000-00-00', '', '2013-10-11 01:33:09', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(80, '', 'Report', '', 'report', '', '', '', '', '', '0000-00-00', '', '2013-10-11 01:34:39', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(81, '', 'Report', '', 'report', '', '', '', '', '', '0000-00-00', '', '2013-10-11 01:35:15', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(82, '', 'Report', '', 'report', '', '', '', '', '', '0000-00-00', '', '2013-10-11 01:43:56', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(83, '', 'Report', '', 'report', '', '', '', '', '', '0000-00-00', '', '2013-10-11 01:44:51', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(100, '', 'Contract', 'adfad', 'contract', '', '', '', '', '', '0000-00-00', '', '2013-10-23 18:36:04', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(98, '', 'Contract', 'asdasd a asdasd', 'contract', '', '', '', '', '', '0000-00-00', '', '2013-10-23 14:37:00', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(99, '', 'Contract', 'adfadfadf', 'contract', '', '', '', '', '', '0000-00-00', '', '2013-10-23 14:53:52', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(94, '', 'Template', 'asdasd', 'template', '', '', '', '', '', '0000-00-00', '', '2013-10-23 14:15:24', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(95, '', 'Template', 'asdasd', 'template', '', '', '', '', '', '0000-00-00', '', '2013-10-23 14:23:59', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(96, '', 'Template', 'asdasd', 'template', '', '', '', '', '', '0000-00-00', '', '2013-10-23 14:26:54', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(97, '', 'Template', 'asdasd', 'template', '', '', '', '', '', '0000-00-00', '', '2013-10-23 14:27:37', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(93, '', 'Report', 'LKASKLDMNALKSDJSDGF NMASDASD', 'report', '', '', '', '', '', '0000-00-00', '', '2013-10-16 15:17:23', 0, 2, 'job2', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(101, '', 'Contract', 'adfad', 'contract', '', '', '', '', '', '0000-00-00', '', '2013-10-23 18:38:59', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(102, '', 'SiteOrder', 'adfadad', 'siteOrder', '', '', '', 'Post Orders', '', '0000-00-00', '', '2013-10-29 16:13:12', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(103, '', 'Training', 'sfdads', 'training', '', '', 'Health & Safety Manuals', '', '', '0000-00-00', '', '2013-10-29 16:15:11', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(104, '', 'KPIAudits', 'adfad', 'KPIAudits', '', '', '', '', '', '0000-00-00', '', '2013-10-29 16:16:21', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(105, '', 'Evidence', 'asdasd asdasd ', 'evidence', 'Auther', '', '', '', '', '2013-12-03', '', '2013-12-03 16:04:09', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(106, '', 'Evidence', 'asdas asdasd', 'evidence', 'Incident Report', 'new author', '', '', '', '2013-12-03', '', '2013-12-03 17:39:45', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(107, '', 'Evidence', 'axcaczczc', 'evidence', 'Line Crossing Sheet', 'test author', '', '', '', '2013-12-03', '', '2013-12-03 17:53:54', 0, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(108, '', 'SiteOrder', 'jhgjhgjhgjh', 'siteOrder', '', '', '', 'Post Orders', '', '0000-00-00', '', '2014-01-07 17:26:23', 3, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(109, '', 'Contract', '111111', 'contract', '', '', '', '', '', '0000-00-00', '', '2014-01-07 17:27:12', 3, 1, 'job1111', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `emailuploads`
--

CREATE TABLE IF NOT EXISTS `emailuploads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `siteOrder` int(11) NOT NULL,
  `training` int(11) NOT NULL,
  `employee` int(11) NOT NULL,
  `KPIAudits` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `contract` int(11) NOT NULL,
  `evidence` int(11) NOT NULL,
  `template` int(11) NOT NULL,
  `report` int(11) NOT NULL,
  `client_feedback` int(11) NOT NULL,
  `afimac_intel` int(11) NOT NULL,
  `news_media` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=39 ;

--
-- Dumping data for table `emailuploads`
--

INSERT INTO `emailuploads` (`id`, `siteOrder`, `training`, `employee`, `KPIAudits`, `member_id`, `contract`, `evidence`, `template`, `report`, `client_feedback`, `afimac_intel`, `news_media`) VALUES
(2, 1, 1, 1, 1, 2, 1, 1, 1, 1, 0, 0, 0),
(5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0),
(7, 1, 1, 1, 1, 4, 1, 1, 1, 1, 0, 0, 0),
(8, 1, 1, 1, 1, 5, 1, 1, 1, 1, 0, 0, 0),
(14, 1, 1, 1, 0, 7, 0, 0, 0, 1, 0, 0, 0),
(26, 1, 1, 1, 1, 9, 1, 1, 1, 1, 0, 1, 1),
(32, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 1),
(37, 0, 0, 0, 0, 6, 0, 0, 0, 0, 0, 1, 1),
(38, 1, 1, 1, 0, 3, 1, 1, 1, 1, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `event_logs`
--

CREATE TABLE IF NOT EXISTS `event_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `time` time NOT NULL,
  `member_id` int(11) NOT NULL,
  `document_id` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `event_type` varchar(255) NOT NULL,
  `event` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=273 ;

--
-- Dumping data for table `event_logs`
--

INSERT INTO `event_logs` (`id`, `date`, `time`, `member_id`, `document_id`, `fullname`, `username`, `event_type`, `event`) VALUES
(1, '2013-07-04 20:46:35', '20:46:35', -100, 0, '', 'justdoit2045@gmail.com', 'User Login', 'Login Failed: Invalid Username or Password'),
(2, '2013-07-04 20:47:36', '20:47:36', -100, 0, '', 'justdoit2045@gmail.com', 'User Login', 'Login Failed: Invalid Username or Password'),
(3, '2013-07-04 21:07:51', '21:07:51', -100, 0, '', 'anwar', 'User Login', 'Login Failed: Invalid Username or Password'),
(4, '2013-07-04 21:08:06', '21:08:06', 1, 0, 'anwar', 'justdoit2045@gmail.com', 'User Login', 'Login SuccessFull'),
(5, '2013-07-05 14:30:07', '14:30:07', 1, 0, 'anwar', 'justdoit2045@gmail.com', 'User Login', 'Login SuccessFull'),
(6, '2013-07-05 16:32:28', '16:32:28', 1, 0, 'anwar', 'justdoit2045@gmail.com', 'User Login', 'Login SuccessFull'),
(7, '2013-07-05 16:48:14', '16:48:14', 0, 1, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload contract'),
(8, '2013-07-05 16:49:52', '16:49:52', 0, 2, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload contract'),
(9, '2013-07-05 16:50:52', '16:50:52', 1, 0, 'anwar', 'justdoit2045@gmail.com', 'User Login', 'Login SuccessFull'),
(10, '2013-07-05 16:51:40', '16:51:40', 1, 3, 'anwar', 'justdoit2045@gmail.com', 'Upload Document', 'Upload contract'),
(11, '2013-07-05 16:53:13', '16:53:13', -100, 0, '', 'warriorbik', 'User Login', 'Login Failed: Invalid Username or Password'),
(12, '2013-07-05 16:53:19', '16:53:19', 2, 0, 'bikash', 'bikash', 'User Login', 'Login SuccessFull'),
(13, '2013-07-05 18:35:01', '18:35:01', 1, 0, 'anwar', 'justdoit2045@gmail.com', 'User Login', 'Login SuccessFull'),
(14, '2013-07-05 18:42:37', '18:42:37', 1, 4, 'anwar', 'justdoit2045@gmail.com', 'Upload Document', 'Upload evidence'),
(15, '2013-07-05 18:44:03', '18:44:03', 2, 0, 'bikash', 'bikash', 'User Login', 'Login SuccessFull'),
(16, '2013-07-05 19:04:15', '19:04:15', 2, 5, 'bikash', 'warriorbik@gmail.com', 'Upload Document', 'Upload client_feedback'),
(17, '2013-07-05 19:08:36', '19:08:36', 2, 3, 'bikash', 'warriorbik@gmail.com', 'Document Viewed', 'Viewed Contract'),
(18, '2013-07-05 20:13:43', '20:13:43', 2, 6, 'bikash', 'warriorbik@gmail.com', 'Upload Document', 'Upload contract'),
(19, '2013-07-05 20:14:09', '20:14:09', 2, 6, 'bikash', 'warriorbik@gmail.com', 'Document Viewed', 'Viewed Contract'),
(20, '2013-07-05 20:36:16', '20:36:16', 0, 6, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Contract'),
(21, '2013-07-05 20:36:58', '20:36:58', -100, 0, '', 'anwar', 'User Login', 'Login Failed: Invalid Username or Password'),
(22, '2013-07-05 20:37:05', '20:37:05', 1, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(23, '2013-07-05 20:38:10', '20:38:10', 1, 1, 'anwar', 'justdoit2045@gmail.com', 'Document Viewed', 'Viewed Contract'),
(24, '2013-07-05 20:38:18', '20:38:18', 1, 2, 'anwar', 'justdoit2045@gmail.com', 'Document Viewed', 'Viewed Contract'),
(25, '2013-07-05 20:38:19', '20:38:19', 1, 2, 'anwar', 'justdoit2045@gmail.com', 'Document Viewed', 'Viewed Contract'),
(26, '2013-07-08 15:10:02', '15:10:02', 1, 0, 'anwar', 'justdoit2045@gmail.com', 'User Login', 'Login SuccessFull'),
(27, '2013-07-08 15:15:32', '15:15:32', 3, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(28, '2013-07-08 15:16:19', '15:16:19', 4, 0, 'bikash', 'bikash', 'User Login', 'Login SuccessFull'),
(29, '2013-07-08 15:16:33', '15:16:33', 5, 0, 'teken', 'teken', 'User Login', 'Login SuccessFull'),
(30, '2013-07-08 15:53:12', '15:53:12', 5, 4, 'teken', 'texabd@gmail.com', 'Document Viewed', 'Viewed Evidence'),
(31, '2013-07-08 16:57:32', '16:57:32', 5, 4, 'teken', 'texabd@gmail.com', 'Document Viewed', 'Viewed Evidence'),
(32, '2013-07-08 18:37:35', '18:37:35', 3, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(33, '2013-07-08 19:30:26', '19:30:26', 4, 0, 'bikash', 'bikash', 'User Login', 'Login SuccessFull'),
(34, '2013-07-08 19:49:55', '19:49:55', 5, 0, 'teken', 'teken', 'User Login', 'Login SuccessFull'),
(35, '2013-07-09 13:45:07', '13:45:07', 3, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(36, '2013-07-09 13:50:18', '13:50:18', 3, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(37, '2013-07-09 15:37:21', '15:37:21', 3, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(38, '2013-07-11 20:57:05', '20:57:05', 0, 5, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Client_feedback'),
(39, '2013-07-12 14:48:56', '14:48:56', 3, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(40, '2013-07-12 15:46:16', '15:46:16', 3, 6, 'anwar', 'justdoit2045@gmail.com', 'Document Viewed', 'Viewed Contract'),
(41, '2013-07-12 16:11:45', '16:11:45', 3, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(42, '2013-07-12 16:19:05', '16:19:05', 3, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(43, '2013-07-18 16:28:23', '16:28:23', 3, 0, 'anwar', 'justdoit2045@gmail.com', 'User Login', 'Login Failed: Invalid Password'),
(44, '2013-07-18 16:28:31', '16:28:31', 3, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(45, '2013-07-19 13:56:17', '13:56:17', -100, 0, '', 'asda', 'User Login', 'Login Failed: Invalid Username or Password'),
(46, '2013-07-19 13:56:42', '13:56:42', -100, 0, '', 'basdasd', 'User Login', 'Login Failed: Invalid Username or Password'),
(47, '2013-07-19 14:01:49', '14:01:49', -100, 0, '', 'asdasd', 'User Login', 'Login Failed: Invalid Username or Password'),
(48, '2013-07-19 14:02:00', '14:02:00', 3, 0, 'anwar', 'anwar', 'User Login', 'Login Failed: Invalid Password'),
(49, '2013-07-19 14:02:13', '14:02:13', 6, 0, 'bhupal', 'bhupal', 'User Login', 'Login Failed: Invalid Password'),
(50, '2013-07-19 14:18:44', '14:18:44', 6, 0, 'bhupal', 'bhupal', 'User Login', 'Login SuccessFull'),
(51, '2013-07-22 18:05:39', '18:05:39', 0, 15, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Contract'),
(52, '2013-07-22 18:06:38', '18:06:38', 0, 15, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Contract'),
(53, '2013-07-24 14:43:07', '14:43:07', 3, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(54, '2013-07-24 15:29:20', '15:29:20', 4, 0, 'bikash', 'bikash', 'User Login', 'Login SuccessFull'),
(55, '2013-07-24 16:46:02', '16:46:02', 3, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(56, '2013-07-25 14:42:39', '14:42:39', 3, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(57, '2013-07-29 17:20:16', '17:20:16', 3, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(58, '2013-07-29 17:21:22', '17:21:22', 3, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(59, '2013-07-29 17:32:33', '17:32:33', 0, 17, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Report'),
(60, '2013-07-29 21:13:49', '21:13:49', 3, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(61, '2013-07-29 21:18:05', '21:18:05', 3, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(62, '2013-07-29 21:21:28', '21:21:28', 3, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(63, '2013-07-29 21:23:58', '21:23:58', 3, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(64, '2013-07-29 21:25:45', '21:25:45', 3, 15, 'anwar', 'justdoit2045@gmail.com', 'Document Viewed', 'Viewed Contract'),
(65, '2013-07-30 09:39:35', '09:39:35', 3, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(66, '2013-07-30 09:41:30', '09:41:30', 3, 1, 'anwar', 'justdoit2045@gmail.com', 'Document Viewed', 'Viewed Contract'),
(67, '2013-07-30 09:41:45', '09:41:45', 3, 7, 'anwar', 'justdoit2045@gmail.com', 'Document Viewed', 'Viewed Evidence'),
(68, '2013-07-30 09:52:04', '09:52:04', 3, 7, 'anwar', 'justdoit2045@gmail.com', 'Document Viewed', 'Viewed Evidence'),
(69, '2013-07-30 15:51:48', '15:51:48', 3, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(70, '2013-07-30 15:51:48', '15:51:48', 3, 15, 'anwar', 'justdoit2045@gmail.com', 'Document Viewed', 'Viewed Contract'),
(71, '2013-07-30 15:52:48', '15:52:48', 3, 15, 'anwar', 'justdoit2045@gmail.com', 'Document Viewed', 'Viewed Contract'),
(72, '2013-08-19 07:37:42', '07:37:42', 3, 0, 'anwar', 'justdoit2045@gmail.com', 'User Login', 'Login Failed: Invalid Password'),
(73, '2013-08-19 07:37:52', '07:37:52', 3, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(74, '2013-08-29 14:44:04', '14:44:04', -100, 0, '', 'admin@admin.com', 'User Login', 'Login Failed: Invalid Username or Password'),
(75, '2013-08-29 14:44:14', '14:44:14', 3, 0, 'anwar', 'justdoit2045@gmail.com', 'User Login', 'Login Failed: Invalid Password'),
(76, '2013-08-29 14:44:20', '14:44:20', 3, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(77, '2013-08-29 15:47:09', '15:47:09', 3, 24, 'anwar', 'justdoit2045@gmail.com', 'Upload Document', 'Upload report'),
(78, '2013-08-29 16:04:42', '16:04:42', 3, 14, 'anwar', 'justdoit2045@gmail.com', 'Document Viewed', 'Viewed Evidence'),
(79, '2013-08-29 16:10:21', '16:10:21', 3, 14, 'anwar', 'justdoit2045@gmail.com', 'Document Viewed', 'Viewed Evidence'),
(80, '2013-08-29 16:13:02', '16:13:02', 3, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(81, '2013-08-29 16:13:25', '16:13:25', 3, 12, 'anwar', 'justdoit2045@gmail.com', 'Document Viewed', 'Viewed Evidence'),
(82, '2013-08-29 16:14:58', '16:14:58', 3, 25, 'anwar', 'justdoit2045@gmail.com', 'Upload Document', 'Upload report'),
(83, '2013-08-29 16:16:19', '16:16:19', 3, 25, 'anwar', 'justdoit2045@gmail.com', 'Document Viewed', 'Viewed Report'),
(84, '2013-08-29 16:20:32', '16:20:32', 3, 24, 'anwar', 'justdoit2045@gmail.com', 'Document Viewed', 'Viewed Report'),
(85, '2013-08-29 16:43:43', '16:43:43', 3, 25, 'anwar', 'justdoit2045@gmail.com', 'Document Viewed', 'Viewed Report'),
(86, '2013-08-29 17:50:35', '17:50:35', 3, 26, 'anwar', 'justdoit2045@gmail.com', 'Upload Document', 'Upload report'),
(87, '2013-08-29 18:50:14', '18:50:14', 3, 31, 'anwar', 'justdoit2045@gmail.com', 'Upload Document', 'Upload report'),
(88, '2013-08-29 18:52:25', '18:52:25', 3, 32, 'anwar', 'justdoit2045@gmail.com', 'Upload Document', 'Upload report'),
(89, '2013-08-29 18:56:36', '18:56:36', 3, 33, 'anwar', 'justdoit2045@gmail.com', 'Upload Document', 'Upload report'),
(90, '2013-09-03 16:03:52', '16:03:52', 0, 34, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload report'),
(91, '2013-09-03 16:14:39', '16:14:39', 0, 36, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload report'),
(92, '2013-09-03 17:06:36', '17:06:36', 0, 14, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Evidence'),
(93, '2013-09-03 17:07:07', '17:07:07', 0, 14, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Evidence'),
(94, '2013-09-03 17:07:24', '17:07:24', 0, 12, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Evidence'),
(95, '2013-09-04 15:11:55', '15:11:55', 0, 37, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload report'),
(96, '2013-09-04 15:20:05', '15:20:05', 0, 38, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload report'),
(97, '2013-09-04 15:46:09', '15:46:09', 0, 38, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Report'),
(98, '2013-09-04 15:48:17', '15:48:17', 0, 39, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload report'),
(99, '2013-09-04 16:40:08', '16:40:08', 0, 40, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload report'),
(100, '2013-09-04 16:44:09', '16:44:09', 0, 41, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload report'),
(101, '2013-09-04 16:44:37', '16:44:37', 0, 42, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload report'),
(102, '2013-09-06 18:02:50', '18:02:50', 0, 14, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Evidence'),
(103, '2013-09-06 18:03:17', '18:03:17', 0, 33, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Report'),
(104, '2013-09-06 18:06:08', '18:06:08', 0, 5, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Client_feedback'),
(105, '2013-09-06 18:07:33', '18:07:33', 0, 15, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Contract'),
(106, '2013-09-09 13:48:21', '13:48:21', -100, 0, '', 'admin', 'User Login', 'Login Failed: Invalid Username or Password'),
(107, '2013-09-10 15:28:00', '15:28:00', 3, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(108, '2013-09-10 15:29:10', '15:29:10', 3, 43, 'anwar', 'justdoit2045@gmail.com', 'Upload Document', 'Upload report'),
(109, '2013-09-10 15:52:17', '15:52:17', 3, 44, 'anwar', 'justdoit2045@gmail.com', 'Upload Document', 'Upload report'),
(110, '2013-09-10 15:53:11', '15:53:11', 3, 44, 'anwar', 'justdoit2045@gmail.com', 'Document Viewed', 'Viewed Report'),
(111, '2013-09-10 15:57:26', '15:57:26', 3, 45, 'anwar', 'justdoit2045@gmail.com', 'Upload Document', 'Upload report'),
(112, '2013-09-10 16:02:14', '16:02:14', 3, 46, 'anwar', 'justdoit2045@gmail.com', 'Upload Document', 'Upload report'),
(113, '2013-09-10 16:03:48', '16:03:48', 3, 46, 'anwar', 'justdoit2045@gmail.com', 'Upload Document', 'Upload report'),
(114, '2013-09-10 16:04:25', '16:04:25', 3, 46, 'anwar', 'justdoit2045@gmail.com', 'Document Viewed', 'Viewed Report'),
(115, '2013-09-10 16:08:47', '16:08:47', 3, 46, 'anwar', 'justdoit2045@gmail.com', 'Upload Document', 'Upload report'),
(116, '2013-09-10 16:10:36', '16:10:36', 3, 45, 'anwar', 'justdoit2045@gmail.com', 'Upload Document', 'Upload report'),
(117, '2013-09-10 20:59:06', '20:59:06', 3, 0, 'anwar', 'justdoit2045@gmail.com', 'User Login', 'Login Failed: Invalid Password'),
(118, '2013-09-10 20:59:21', '20:59:21', 3, 0, 'anwar', 'justdoit2045@gmail.com', 'User Login', 'Login Failed: Invalid Password'),
(119, '2013-09-10 21:16:32', '21:16:32', 0, 47, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload evidence'),
(120, '2013-09-10 21:17:23', '21:17:23', 0, 47, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Evidence'),
(121, '2013-09-10 21:22:43', '21:22:43', 0, 48, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload evidence'),
(122, '2013-09-10 21:23:02', '21:23:02', 0, 48, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Evidence'),
(123, '2013-09-10 21:43:35', '21:43:35', 0, 49, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload report'),
(124, '2013-09-10 21:43:42', '21:43:42', 0, 49, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Report'),
(125, '2013-09-11 13:39:30', '13:39:30', 3, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(126, '2013-09-11 13:40:04', '13:40:04', 3, 50, 'anwar', 'justdoit2045@gmail.com', 'Upload Document', 'Upload report'),
(127, '2013-09-11 14:02:32', '14:02:32', 3, 50, 'anwar', 'justdoit2045@gmail.com', 'Upload Document', 'Upload report'),
(128, '2013-09-11 15:09:38', '15:09:38', 3, 0, 'anwar', 'anwar', 'User Login', 'Login Failed: Invalid Password'),
(129, '2013-09-11 15:09:53', '15:09:53', 3, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(130, '2013-09-11 16:11:14', '16:11:14', 0, 48, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Evidence'),
(131, '2013-09-11 16:11:23', '16:11:23', 0, 47, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Evidence'),
(132, '2013-09-11 16:17:28', '16:17:28', 0, 51, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload evidence'),
(133, '2013-09-17 20:16:27', '20:16:27', -100, 0, '', 'justdoit.2045@yahoo.com', 'User Login', 'Login Failed: Invalid Username or Password'),
(134, '2013-09-17 20:16:51', '20:16:51', -100, 0, '', 'justdoit.2045@yahoo.com', 'User Login', 'Login Failed: Invalid Username or Password'),
(135, '2013-09-17 20:18:10', '20:18:10', -100, 0, '', 'justdoit.2045@yahoo.com', 'User Login', 'Login Failed: Invalid Username or Password'),
(136, '2013-09-17 20:18:22', '20:18:22', -100, 0, '', 'justdoit.2045@yahoo.com', 'User Login', 'Login Failed: Invalid Username or Password'),
(137, '2013-09-17 20:18:44', '20:18:44', 3, 0, 'anwar', 'anwar', 'User Login', 'Login Failed: Invalid Password'),
(138, '2013-09-19 15:11:20', '15:11:20', -100, 0, '', 'admin', 'User Login', 'Login Failed: Invalid Username or Password'),
(139, '2013-09-23 16:17:57', '16:17:57', 3, 0, 'anwar', 'anwar', 'User Login', 'Login Failed: Invalid Password'),
(140, '2013-09-23 16:27:43', '16:27:43', 3, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(141, '2013-09-23 16:48:08', '16:48:08', 0, 52, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload contract'),
(142, '2013-09-23 16:54:04', '16:54:04', 0, 53, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload contract'),
(143, '2013-09-23 17:04:54', '17:04:54', 0, 56, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload contract'),
(144, '2013-09-23 17:06:20', '17:06:20', 0, 57, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload contract'),
(145, '2013-09-23 17:08:29', '17:08:29', 0, 59, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload contract'),
(146, '2013-09-24 13:51:20', '13:51:20', 3, 0, 'anwar', 'justdoit2045@gmail.com', 'User Login', 'Login Failed: Invalid Password'),
(147, '2013-09-24 16:03:30', '16:03:30', 3, 0, 'anwar', 'anwar', 'User Login', 'Login Failed: Invalid Password'),
(148, '2013-09-24 16:03:39', '16:03:39', 3, 0, 'anwar', 'anwar', 'User Login', 'Login Failed: Invalid Password'),
(149, '2013-09-24 16:03:50', '16:03:50', 3, 0, 'anwar', 'anwar', 'User Login', 'Login Failed: Invalid Password'),
(150, '2013-09-24 16:05:32', '16:05:32', 3, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(151, '2013-09-24 16:06:22', '16:06:22', 3, 60, 'anwar', 'justdoit2045@gmail.com', 'Upload Document', 'Upload report'),
(152, '2013-09-24 16:13:29', '16:13:29', 3, 28, 'anwar', 'justdoit2045@gmail.com', 'Upload Document', 'Upload report'),
(153, '2013-10-10 13:58:24', '13:58:24', 0, 61, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload contract'),
(154, '2013-10-11 01:10:21', '01:10:21', 0, 70, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload report'),
(155, '2013-10-14 05:37:48', '05:37:48', 0, 93, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload report'),
(156, '2013-10-14 05:44:01', '05:44:01', 0, 93, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload report'),
(157, '2013-10-14 06:05:11', '06:05:11', 0, 93, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Report'),
(158, '2013-10-14 06:06:48', '06:06:48', 0, 93, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Report'),
(159, '2013-10-14 07:32:43', '07:32:43', 0, 93, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Report'),
(160, '2013-10-14 07:33:25', '07:33:25', 0, 93, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Report'),
(161, '2013-10-14 07:34:17', '07:34:17', 0, 93, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Report'),
(162, '2013-10-14 07:39:06', '07:39:06', 0, 93, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Report'),
(163, '2013-10-14 07:39:57', '07:39:57', 0, 93, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Report'),
(164, '2013-10-14 07:43:15', '07:43:15', 0, 93, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Report'),
(165, '2013-10-14 07:45:16', '07:45:16', 0, 93, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Report'),
(166, '2013-10-14 07:47:46', '07:47:46', 0, 93, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Report'),
(167, '2013-10-14 07:51:01', '07:51:01', 0, 93, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Report'),
(168, '2013-10-14 07:51:31', '07:51:31', 0, 93, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Report'),
(169, '2013-10-14 07:52:38', '07:52:38', 0, 93, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Report'),
(170, '2013-10-15 13:22:18', '13:22:18', 0, 93, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Report'),
(171, '2013-10-15 13:23:11', '13:23:11', 0, 93, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Report'),
(172, '2013-10-15 13:23:28', '13:23:28', 0, 93, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Report'),
(173, '2013-10-15 13:33:57', '13:33:57', 0, 93, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Report'),
(174, '2013-10-15 13:36:29', '13:36:29', 0, 93, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Report'),
(175, '2013-10-15 13:38:47', '13:38:47', 0, 93, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Report'),
(176, '2013-10-15 13:41:20', '13:41:20', 0, 17, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Report'),
(177, '2013-10-16 15:09:40', '15:09:40', 0, 93, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload report'),
(178, '2013-10-16 15:10:15', '15:10:15', 0, 93, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Report'),
(179, '2013-10-16 15:11:47', '15:11:47', 0, 93, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Report'),
(180, '2013-10-16 15:17:23', '15:17:23', 0, 93, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload report'),
(181, '2013-10-16 15:18:19', '15:18:19', 0, 93, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Report'),
(182, '2013-10-23 13:58:28', '13:58:28', 0, 61, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload template'),
(183, '2013-10-23 14:00:28', '14:00:28', 0, 61, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload contract'),
(184, '2013-10-23 14:08:43', '14:08:43', 0, 61, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload template'),
(185, '2013-10-23 14:15:33', '14:15:33', 0, 94, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload template'),
(186, '2013-10-23 14:15:50', '14:15:50', 0, 94, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Template'),
(187, '2013-10-23 14:27:45', '14:27:45', 0, 97, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload template'),
(188, '2013-10-23 14:28:09', '14:28:09', 0, 97, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Template'),
(189, '2013-10-23 14:37:08', '14:37:08', 0, 98, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload contract'),
(190, '2013-10-23 14:38:02', '14:38:02', 0, 98, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Contract'),
(191, '2013-10-23 14:54:01', '14:54:01', 0, 99, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload contract'),
(192, '2013-10-23 14:54:29', '14:54:29', 0, 99, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Contract'),
(193, '2013-10-23 14:55:27', '14:55:27', 0, 99, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Contract'),
(194, '2013-10-23 18:36:10', '18:36:10', 0, 100, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload contract'),
(195, '2013-10-23 18:36:21', '18:36:21', 0, 100, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Contract'),
(196, '2013-10-23 18:39:06', '18:39:06', 0, 101, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload contract'),
(197, '2013-10-23 18:39:15', '18:39:15', 0, 101, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Contract'),
(198, '2013-10-23 18:47:01', '18:47:01', 0, 101, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Contract'),
(199, '2013-10-29 16:13:20', '16:13:20', 0, 102, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload siteOrder'),
(200, '2013-10-29 16:15:21', '16:15:21', 0, 103, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload training'),
(201, '2013-10-29 16:16:21', '16:16:21', 0, 104, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload KPIAudits'),
(202, '2013-10-29 16:36:25', '16:36:25', 3, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(203, '2013-10-31 14:48:14', '14:48:14', 3, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(204, '2013-11-24 02:10:47', '02:10:47', -100, 0, '', 'justdoit_2045@hotmail.com', 'User Login', 'Login Failed: Invalid Username or Password'),
(205, '2013-12-03 15:06:48', '15:06:48', 3, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(206, '2013-12-03 15:25:36', '15:25:36', 3, 37, 'anwar', 'justdoit2045@gmail.com', 'Document Viewed', 'Viewed Report'),
(207, '2013-12-03 15:53:52', '15:53:52', 0, 105, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload evidence'),
(208, '2013-12-03 16:04:09', '16:04:09', 0, 105, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload evidence'),
(209, '2013-12-03 16:06:30', '16:06:30', 0, 106, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload evidence'),
(210, '2013-12-03 16:07:29', '16:07:29', 0, 105, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Evidence'),
(211, '2013-12-03 16:07:41', '16:07:41', 0, 105, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Evidence'),
(212, '2013-12-03 17:36:46', '17:36:46', 0, 106, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload evidence'),
(213, '2013-12-03 17:39:45', '17:39:45', 0, 106, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload evidence'),
(214, '2013-12-03 17:54:00', '17:54:00', 0, 107, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload evidence'),
(215, '2013-12-23 15:39:15', '15:39:15', 3, 0, 'anwar', 'justdoit2045@gmail.com', 'User Login', 'Login Failed: Invalid Password'),
(216, '2013-12-24 13:24:23', '13:24:23', 0, 0, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload AFIMAC Intel'),
(217, '2013-12-24 13:54:38', '13:54:38', 0, 0, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload AFIMAC Intel'),
(218, '2013-12-24 13:54:53', '13:54:53', 0, 0, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload News/Media'),
(219, '2013-12-30 14:41:29', '14:41:29', -100, 0, '', 'justdoit.2045@yahoo.comq', 'User Login', 'Login Failed: Invalid Username or Password'),
(220, '2013-12-30 15:04:15', '15:04:15', 8, 0, 'aaaa', 'aaaa', 'User Login', 'Login Failed: Invalid Password'),
(221, '2013-12-31 03:28:57', '03:28:57', 8, 0, 'aaaa', 'aaaa', 'User Login', 'Login Failed: Invalid Password'),
(222, '2013-12-31 03:29:03', '03:29:03', 8, 0, 'aaaa', 'aaaa', 'User Login', 'Login Failed: Invalid Password'),
(223, '2013-12-31 03:29:15', '03:29:15', 8, 0, 'aaaa', 'aaaa', 'User Login', 'Login Failed: Invalid Password'),
(224, '2013-12-31 03:29:23', '03:29:23', 8, 0, 'aaaa', 'aaaa', 'User Login', 'Login Failed: Invalid Password'),
(225, '2013-12-31 03:29:35', '03:29:35', 8, 0, 'aaaa', 'aaaa', 'User Login', 'Login Failed: Invalid Password'),
(226, '2013-12-31 03:29:45', '03:29:45', 8, 0, 'aaaa', 'aaaa', 'User Login', 'Login Failed: Invalid Password'),
(227, '2013-12-31 03:31:36', '03:31:36', 8, 0, 'aaaa', 'aaaa', 'User Login', 'Login SuccessFull'),
(228, '2013-12-31 14:11:47', '14:11:47', 8, 0, 'aaaa', 'aaaa', 'User Login', 'Login SuccessFull'),
(229, '2013-12-31 16:41:33', '16:41:33', 8, 0, 'aaaa', 'aaaa', 'User Login', 'Login SuccessFull'),
(230, '2013-12-31 17:29:34', '17:29:34', 0, 101, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Contract'),
(231, '2013-12-31 17:31:27', '17:31:27', 8, 0, 'aaaa', 'aaaa', 'User Login', 'Login SuccessFull'),
(232, '2013-12-31 17:35:59', '17:35:59', 8, 0, 'aaaa', 'aaaa', 'User Login', 'Login SuccessFull'),
(233, '2013-12-31 17:44:19', '17:44:19', 8, 0, 'aaaa', 'aaaa', 'User Login', 'Login SuccessFull'),
(234, '2013-12-31 18:05:15', '18:05:15', 8, 0, 'aaaa', 'aaaa', 'User Login', 'Login SuccessFull'),
(235, '2014-01-03 15:38:25', '15:38:25', 8, 0, 'aaaa', 'aaaa', 'User Login', 'Login SuccessFull'),
(236, '2014-01-03 16:20:21', '16:20:21', 8, 8, 'aaaa', '', 'Upload Document', 'Upload AFIMAC Intel'),
(237, '2014-01-06 14:46:13', '14:46:13', 8, 0, 'aaaa', 'aaaa', 'User Login', 'Login SuccessFull'),
(238, '2014-01-06 14:59:55', '14:59:55', 8, 0, 'aaaa', 'aaaa', 'User Login', 'Login SuccessFull'),
(239, '2014-01-06 15:27:34', '15:27:34', 8, 0, 'aaaa', 'aaaa', 'User Login', 'Login SuccessFull'),
(240, '2014-01-06 15:27:58', '15:27:58', 8, 8, 'aaaa', '', 'Upload Document', 'Upload AFIMAC Intel'),
(241, '2014-01-06 15:34:49', '15:34:49', 8, 0, 'aaaa', 'aaaa', 'User Login', 'Login SuccessFull'),
(242, '2014-01-06 15:35:59', '15:35:59', 8, 0, 'aaaa', 'aaaa', 'User Login', 'Login SuccessFull'),
(243, '2014-01-07 04:11:25', '04:11:25', 3, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(244, '2014-01-07 04:11:49', '04:11:49', -100, 0, '', 'admin', 'User Login', 'Login Failed: Invalid Username or Password'),
(245, '2014-01-07 15:01:40', '15:01:40', 8, 0, 'aaaa', 'aaaa', 'User Login', 'Login SuccessFull'),
(246, '2014-01-07 15:05:25', '15:05:25', 8, 0, 'aaaa', 'aaaa', 'User Login', 'Login SuccessFull'),
(247, '2014-01-07 15:10:27', '15:10:27', 8, 0, 'aaaa', 'aaaa', 'User Login', 'Login SuccessFull'),
(248, '2014-01-07 15:12:22', '15:12:22', 8, 0, 'aaaa', 'aaaa', 'User Login', 'Login SuccessFull'),
(249, '2014-01-07 15:49:35', '15:49:35', 8, 0, 'aaaa', 'aaaa', 'User Login', 'Login SuccessFull'),
(250, '2014-01-07 17:11:47', '17:11:47', 0, 0, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload News/Media'),
(251, '2014-01-07 17:24:02', '17:24:02', -100, 0, '', '1', 'User Login', 'Login Failed: Invalid Username or Password'),
(252, '2014-01-07 17:25:08', '17:25:08', 3, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(253, '2014-01-07 17:26:24', '17:26:24', 3, 108, 'anwar', 'justdoit2045@gmail.com', 'Upload Document', 'Upload siteOrder'),
(254, '2014-01-07 17:27:12', '17:27:12', 3, 109, 'anwar', 'justdoit2045@gmail.com', 'Upload Document', 'Upload contract'),
(255, '2014-01-07 17:36:09', '17:36:09', 8, 0, 'aaaa', 'aaaa', 'User Login', 'Login SuccessFull'),
(256, '2014-01-07 18:13:25', '18:13:25', 8, 8, 'aaaa', '', 'Upload Document', 'Upload News/Media'),
(257, '2014-01-08 15:29:33', '15:29:33', 8, 0, 'aaaa', 'aaaa', 'User Login', 'Login SuccessFull'),
(258, '2014-01-08 15:50:22', '15:50:22', 8, 0, 'aaaa', 'aaaa', 'User Login', 'Login SuccessFull'),
(259, '2014-01-08 15:51:42', '15:51:42', 3, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(260, '2014-01-14 17:17:14', '17:17:14', 0, 0, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload AFIMAC Intel'),
(261, '2014-01-14 17:44:20', '17:44:20', 0, 0, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload AFIMAC Intel'),
(262, '2014-02-21 04:16:31', '04:16:31', 3, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(263, '2014-02-21 04:17:46', '04:17:46', 6, 0, 'bhupal', 'bhupal', 'User Login', 'Login Failed: Invalid Password'),
(264, '2014-02-21 04:17:54', '04:17:54', 5, 0, 'teken', 'teken', 'User Login', 'Login Failed: Invalid Password'),
(265, '2014-02-21 04:19:03', '04:19:03', 6, 0, 'bhupal', 'bhupal', 'User Login', 'Login SuccessFull'),
(266, '2014-02-21 06:36:20', '06:36:20', 6, 0, 'bhupal', 'bhupal', 'User Login', 'Login SuccessFull'),
(267, '2014-02-21 06:36:52', '06:36:52', 3, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(268, '2014-02-27 05:49:13', '05:49:13', 0, 0, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload AFIMAC Intel'),
(269, '2014-02-27 05:53:20', '05:53:20', 0, 0, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Upload Document', 'Upload AFIMAC Intel'),
(270, '2014-02-28 22:32:13', '22:32:13', 0, 6, 'ADMIN(Admin1)', 'justdoit.2045@yahoo.com', 'Document Viewed', 'Viewed Contract'),
(271, '2014-03-01 02:44:24', '02:44:24', 3, 0, 'anwar', 'anwar', 'User Login', 'Login SuccessFull'),
(272, '2014-03-01 02:46:45', '02:46:45', -100, 0, '', 'justdoit.2045@hotmail.com', 'User Login', 'Login Failed: Invalid Username or Password');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE IF NOT EXISTS `images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `document_id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `document_id`, `image`) VALUES
(1, 2, 'Contract_asdhf_asjk_2013-07-05_16-49-52.png'),
(2, 6, 'Contract_adkfja_dfa_2013-07-05_20-13-43.jpg'),
(3, 41, 'Report_activityLog_2013-09-04_16-44-09.png'),
(4, 93, 'Report_2013-10-16_15-09-40.png');

-- --------------------------------------------------------

--
-- Table structure for table `item_infos`
--

CREATE TABLE IF NOT EXISTS `item_infos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ids` int(11) NOT NULL,
  `doc_id` int(11) NOT NULL,
  `case` varchar(255) NOT NULL,
  `desc` varchar(255) NOT NULL,
  `sku` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=41 ;

--
-- Dumping data for table `item_infos`
--

INSERT INTO `item_infos` (`id`, `ids`, `doc_id`, `case`, `desc`, `sku`, `price`) VALUES
(1, 1, 92, 'bbdbdfb', '1', '1', '1'),
(2, 2, 92, 'bbdbdfb', '2', '22', '2'),
(3, 3, 92, 'bbdbdfb', '3', '33', '3'),
(4, 4, 92, 'bbdbdfb', '4', '4', '4'),
(5, 5, 92, 'bbdbdfb', '5', '5', '56'),
(6, 6, 92, 'bbdbdfb', '66', '6', '6'),
(7, 7, 92, 'bbdbdfb', '7', '77', '7'),
(8, 8, 92, 'bbdbdfb', '8', '8', '8'),
(40, 8, 93, 'bbdbdfb1', '4Q', '4Q', '4Q'),
(39, 7, 93, 'bbdbdfb1', '3Q', '33Q', '3Q'),
(38, 6, 93, 'bbdbdfb1', '2Q', '22Q', '2Q'),
(33, 1, 93, 'bbdbdfb1', '5Q', '5Q', '56Q'),
(34, 2, 93, 'bbdbdfb1', '66Q', '6Q', '6Q'),
(35, 3, 93, 'bbdbdfb1', '7Q', '77Q', '7Q'),
(36, 4, 93, 'bbdbdfb1', '8Q', '88Q', '8Q'),
(37, 5, 93, 'bbdbdfb1', '1Q', '1Q', '1Q');

-- --------------------------------------------------------

--
-- Table structure for table `jobmembers`
--

CREATE TABLE IF NOT EXISTS `jobmembers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job_id` varchar(255) NOT NULL,
  `member_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=52 ;

--
-- Dumping data for table `jobmembers`
--

INSERT INTO `jobmembers` (`id`, `job_id`, `member_id`) VALUES
(3, '4,3,1,2,6,7,8,9,5,11', 3),
(4, '10', 4),
(5, '10', 5),
(6, '10', 6),
(7, '2,3,4', 7),
(8, '', 8),
(9, '', 9);

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE IF NOT EXISTS `jobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `addedBy` int(11) NOT NULL COMMENT '0:admin other:user',
  `isApproved` int(11) NOT NULL COMMENT '1:approved, 0:not approved',
  `date_start` date DEFAULT NULL,
  `date_end` date DEFAULT NULL,
  `is_special` int(11) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0=>active -recuirtment only, 1=>proposal submitted, 2=>signed contract,  3=>proposal settled, 4=>lost of competitor',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`id`, `title`, `description`, `image`, `addedBy`, `isApproved`, `date_start`, `date_end`, `is_special`, `status`) VALUES
(1, 'job1111', 'job description', 'afimaclogo.png', 0, 1, '2013-07-05', '2013-07-20', 0, 0),
(2, 'job2', 'job desc 2', 'afimaclogo.png', 0, 1, '2013-07-10', '2013-07-31', 0, 0),
(3, 'job 3', 'job 3 description', 'afimaclogo.png', 0, 1, '2013-07-20', '2013-07-31', 0, 0),
(4, 'adfadfadf', 'adfadfadf', 'afimaclogo.png', 0, 1, '2013-07-20', '2013-07-31', 0, 0),
(5, 'qwqwe', 'qweqwe', 'afimaclogo.png', 0, 1, '2013-09-11', '2013-09-30', 0, 0),
(6, 'new', 'asdasd', 'afimaclogo.png', 0, 1, '2013-09-11', '2013-09-18', 0, 0),
(7, 'new', 'asdasd', 'afimaclogo.png', 0, 1, '2013-09-11', '2013-09-18', 0, 0),
(8, 'new', 'asdasd', 'afimaclogo.png', 0, 1, '2013-09-11', '2013-09-18', 0, 0),
(9, 'project', 'adfadsf', 'afimaclogo.png', 0, 1, '2013-10-29', '2013-10-29', 0, 0),
(10, 'Special', 'sample description', '', 0, 1, NULL, NULL, 1, 0),
(11, 'statrus', 'asd', 'afimaclogo.png', 0, 1, '2014-01-08', '2014-01-22', 0, 4);

-- --------------------------------------------------------

--
-- Table structure for table `job_contacts`
--

CREATE TABLE IF NOT EXISTS `job_contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job_id` int(11) NOT NULL,
  `key_id` int(11) NOT NULL,
  `type` int(11) NOT NULL COMMENT '0=>keycontacts, 1=>staffcontacts, thirdpartycontacts',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=74 ;

--
-- Dumping data for table `job_contacts`
--

INSERT INTO `job_contacts` (`id`, `job_id`, `key_id`, `type`) VALUES
(1, 5, 1, 0),
(3, 3, 23, 2),
(28, 0, 0, 0),
(31, 0, 0, 0),
(33, 0, 0, 0),
(34, 1, 34, 0),
(35, 1, 35, 1),
(36, 1, 36, 1),
(37, 1, 37, 2),
(38, 9, 33, 0),
(39, 9, 41, 0),
(69, 11, 33, 0),
(70, 10, 33, 0),
(71, 10, 34, 0),
(72, 10, 35, 1),
(73, 10, 36, 1);

-- --------------------------------------------------------

--
-- Table structure for table `juvenile_infos`
--

CREATE TABLE IF NOT EXISTS `juvenile_infos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `doc_id` int(11) NOT NULL,
  `l_name_adult` varchar(255) NOT NULL,
  `f_name_adult` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL,
  `adult_id` varchar(255) NOT NULL,
  `p_sign` varchar(255) NOT NULL,
  `called` varchar(255) NOT NULL,
  `eta` varchar(255) NOT NULL,
  `arrived` varchar(255) NOT NULL,
  `left` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `juvenile_infos`
--

INSERT INTO `juvenile_infos` (`id`, `doc_id`, `l_name_adult`, `f_name_adult`, `time`, `adult_id`, `p_sign`, `called`, `eta`, `arrived`, `left`) VALUES
(1, 85, '', '', 'sdasdasd', '', '', 'asgfdsfg', 'asdasd', 'fgbffgd', 'asdasd'),
(2, 86, 'aasdas', 'dfdfg', 'cvbcvbcvbc', 'asdasdasd', 'sdfsfasd', 'asd', 'asdas', 'asdasd', 'asdasd'),
(3, 87, 'aasdas', 'dfdfg', 'cvbcvbcvbc', 'asdasdasd', 'sdfsfasd', 'asd', 'asdas', 'asdasd', 'asdasd'),
(4, 88, 'aasdas', 'dfdfg', 'cvbcvbcvbc', 'asdasdasd', 'sdfsfasd', 'asd', 'asdas', 'asdasd', 'asdasd'),
(5, 89, 'aasdas', 'dfdfg', 'cvbcvbcvbc', 'asdasdasd', 'sdfsfasd', 'asd', 'asdas', 'asdasd', 'asdasd'),
(6, 90, 'aasdas', 'dfdfg', 'cvbcvbcvbc', 'asdasdasd', 'sdfsfasd', 'asd', 'asdas', 'asdasd', 'asdasd'),
(7, 91, 'aasdas', 'dfdfg', 'cvbcvbcvbc', 'asdasdasd', 'sdfsfasd', 'asd', 'asdas', 'asdasd', 'asdasd'),
(8, 92, 'aasdas', 'dfdfg', 'cvbcvbcvbc', 'asdasdasd', 'sdfsfasd', 'asd', 'asdas', 'asdasd', 'asdasd'),
(12, 93, 'aasdas1', 'dfdfg1', 'cvbcvbcvbc1', 'asdasdasd1', 'sdfsfasd1', 'asd1', 'asdas1', 'asdasd1', 'asdasd1');

-- --------------------------------------------------------

--
-- Table structure for table `key_contacts`
--

CREATE TABLE IF NOT EXISTS `key_contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `cell` varchar(255) NOT NULL,
  `cellular_provider` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `type` int(11) NOT NULL COMMENT '0=>keycontacts, 1=>staffcontacts, thirdpartycontacts',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=43 ;

--
-- Dumping data for table `key_contacts`
--

INSERT INTO `key_contacts` (`id`, `job_id`, `name`, `email`, `cell`, `cellular_provider`, `title`, `company`, `phone`, `type`) VALUES
(33, 0, 'adfadf', 'ass@bb.com', '9988', 'Verizon', 'adfadf', 'adfadsf', '88899', 0),
(34, 0, 'adfadf', 'ss@cc.com', '9988', 'Rogers', 'adfadf', 'adfadsf', '88899', 0),
(35, 0, 'adfadf', 'adfadf@com.com', '8787878', 'Rogers', 'adfadf', 'aadfadfadf', '9988998899', 1),
(36, 0, 'adfadf', 'adfad@aaa.com', '878787', 'Rogers', 'adfadf', 'adfadf', '9898989898', 1),
(37, 0, 'adfadf', 'kjhkjh@adfhgjadfg.com', '8787878787', 'Rogers', 'aaa', 'adfad', '87876876876', 2),
(41, 0, 'adfadf', 'adfad.com', '9988', 'rogers', 'adfadf', 'adfadsf', '88899', 0),
(42, 0, 'adfadf', 'aa.coms', '9988', 'rogers', 'adfadf', 'adfadsf', '88899', 0);

-- --------------------------------------------------------

--
-- Table structure for table `lastsenders`
--

CREATE TABLE IF NOT EXISTS `lastsenders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first` int(11) NOT NULL,
  `second` int(11) NOT NULL DEFAULT '-1',
  `parent` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `lastsenders`
--

INSERT INTO `lastsenders` (`id`, `first`, `second`, `parent`) VALUES
(8, 0, -1, 7),
(7, 3, 0, 4),
(6, 0, 3, 4),
(9, 3, 0, 7),
(10, 4, 0, 7),
(11, 0, -1, 8),
(12, 3, 0, 8),
(13, 0, -1, 9),
(14, 3, 0, 9),
(15, 0, -1, 10),
(16, 3, 0, 10),
(17, 0, -1, 11),
(18, 3, 0, 11);

-- --------------------------------------------------------

--
-- Table structure for table `logos`
--

CREATE TABLE IF NOT EXISTS `logos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `afimac` int(11) NOT NULL,
  `asap` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `logos`
--

INSERT INTO `logos` (`id`, `afimac`, `asap`) VALUES
(1, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `mailreads`
--

CREATE TABLE IF NOT EXISTS `mailreads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL,
  `parent` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `mailreads`
--

INSERT INTO `mailreads` (`id`, `user`, `parent`, `status`) VALUES
(11, 0, 7, -1),
(10, 0, 0, 1),
(9, 3, 4, 1),
(8, 0, 4, 1),
(12, 3, 7, 1),
(13, 4, 7, 0),
(14, 0, 0, 1),
(15, 0, 8, -1),
(16, 3, 8, 1),
(17, 0, 9, -1),
(18, 3, 9, 1),
(19, 0, 10, -1),
(20, 3, 10, 0),
(21, 0, 11, -1),
(22, 3, 11, 1);

-- --------------------------------------------------------

--
-- Table structure for table `mails`
--

CREATE TABLE IF NOT EXISTS `mails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender` varchar(255) NOT NULL,
  `recipients_id` varchar(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `status` varchar(255) NOT NULL COMMENT 'read/unread',
  `date` datetime NOT NULL,
  `attachment` text NOT NULL,
  `sender_id` int(11) NOT NULL,
  `delete_for` varchar(255) NOT NULL,
  `parent` int(11) NOT NULL,
  `is_replyall` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `mails`
--

INSERT INTO `mails` (`id`, `sender`, `recipients_id`, `subject`, `message`, `status`, `date`, `attachment`, `sender_id`, `delete_for`, `parent`, `is_replyall`) VALUES
(5, 'anwar', '0', 'test', 'sample reply goes here', 'unread', '2013-07-09 14:03:36', '', 3, '', 4, 0),
(4, 'Admin', '3', 'test', 'testing now', 'unread', '2013-07-09 14:02:17', '', 0, '', 0, 0),
(6, 'admin', '3', 'test', 'sample reply goes here', 'unread', '2013-07-09 14:04:18', '', 0, '', 4, 0),
(7, 'Admin', '3,4', 'test2', 'test2', 'unread', '2013-07-09 14:10:54', '', 0, '', 0, 0),
(8, 'Admin', '3', 'test', 'Test message', 'unread', '2013-07-09 15:36:58', '5,Contract_jasdfh_akj_2013-07-05_16-51-39.txt', 0, '', 0, 0),
(9, 'Admin', '3', 'tedst', 'adfjhas dfjah dkjfhask djfh akdjsfha kdjfhasjdkf has', 'unread', '2013-07-29 17:19:23', '', 0, '', 0, 0),
(10, 'Admin', '3', 'Test subject', 'Test message gies here and there.', 'unread', '2013-07-30 09:37:46', 'Contract_akjsdfh_ak_2013-07-05_16-48-14.txt,Contract_asdhf_asjk_2013-07-05_16-49-52.png', 0, '', 0, 0),
(11, 'Admin', '3', 'test attach', 'test message goes here', 'unread', '2013-07-30 09:40:31', 'Contract_akjsdfh_ak_2013-0-05_16-48-14.txt,Contract_asdhf_asjk_2013-07-05_16-49-52.png,7', 0, '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE IF NOT EXISTS `members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `canView` int(11) NOT NULL,
  `canUpdate` int(11) NOT NULL,
  `canEmail` int(11) NOT NULL,
  `isSupervisor` int(11) NOT NULL,
  `isEmployee` int(11) NOT NULL,
  `canEdit` int(11) NOT NULL,
  `receive1` int(11) NOT NULL,
  `receive2` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `full_name`, `fname`, `lname`, `title`, `address`, `email`, `phone`, `password`, `image`, `canView`, `canUpdate`, `canEmail`, `isSupervisor`, `isEmployee`, `canEdit`, `receive1`, `receive2`) VALUES
(3, 'anwar', 'user', '1', 'mr', 'test', 'justdoit2045.@gmail.com', '132123123', '46d923d9b44b8aaaf3179c5f6f7adf81', 'male.png', 1, 1, 1, 0, 0, 1, 1, 1),
(4, 'bikash', 'user', '2', 'mr', 'test', 'warriorbik@gmail.com', '98787667576', '79625badf4f74593088cc598cdb34105', 'male.png', 1, 1, 1, 0, 0, 1, 1, 1),
(5, 'teken', 'user', '3', 'mr', 'test', 'texabd@gmail.com', '425245245', '47f4fd33529ca6167ae7124559ea947f', 'male.png', 1, 1, 1, 0, 0, 1, 1, 1),
(6, 'bhupal', 'Bhupal', 'test', 'afda', 'adsfadf', 'justdoit2045@gmail.com', '87987987987', '53196de8945b5dcbafecff957e546267', 'male.png', 1, 1, 1, 0, 0, 1, 1, 1),
(7, 'aaa', 'adfadf', 'aefadfa', 'aaa', 'adfasdf', '', '344343434', 'd4fbb7d8d5603db43ac2094f5955787c', 'male.png', 1, 1, 1, 0, 0, 1, 1, 1),
(8, 'aaaa', 'adfadfadf', 'adf', 'aaaa', 'aaaa', '', '', 'f3f866ace1d3e4e6ab0aea76d0fdaef5', 'male.png', 1, 1, 0, 0, 0, 0, 0, 1),
(9, 'asdf', 'tests', 'ajdksfhk', 'aa', 'adfadf', 'aaa@bbb.com', '7676767676', '0b4e7a0e5fe84ad35fb5f95b9ceeac79', 'male.png', 1, 1, 1, 0, 0, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `notice_infos`
--

CREATE TABLE IF NOT EXISTS `notice_infos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `doc_id` int(11) NOT NULL,
  `given` varchar(255) NOT NULL,
  `desc` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `notice_infos`
--

INSERT INTO `notice_infos` (`id`, `doc_id`, `given`, `desc`) VALUES
(1, 91, 'no', 'fgdgdsfgfdsga'),
(2, 92, 'no', 'fgdgdsfgfdsga'),
(6, 93, 'no', '1aasA ASOJDH OSDIFH ASDF');

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE IF NOT EXISTS `pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `pages`
--


-- --------------------------------------------------------

--
-- Table structure for table `police_infos`
--

CREATE TABLE IF NOT EXISTS `police_infos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `doc_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `agency` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL,
  `badge` varchar(255) NOT NULL,
  `incident` varchar(255) NOT NULL,
  `called` varchar(255) NOT NULL,
  `eta` varchar(255) NOT NULL,
  `arrived` varchar(255) NOT NULL,
  `left` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `police_infos`
--

INSERT INTO `police_infos` (`id`, `doc_id`, `name`, `agency`, `time`, `badge`, `incident`, `called`, `eta`, `arrived`, `left`) VALUES
(1, 91, 'asd', 'dfgdfa', 'sdasdasd', 'sdfsdf', 'asdas', 'asgfdsfg', 'asdasd', 'fgbffgd', 'asdasd'),
(2, 92, 'asd', 'dfgdfa', 'sdasdasd', 'sdfsdf', 'asdas', 'asgfdsfg', 'asdasd', 'fgbffgd', 'asdasd'),
(6, 93, 'asd1', 'dfgdfa1', 'sdasdasd1', 'sdfsdf1', 'asdas1', 'asgfdsfg1', 'asdasd1', 'fgbffgd1', 'asdasd1');

-- --------------------------------------------------------

--
-- Table structure for table `product_d_infos`
--

CREATE TABLE IF NOT EXISTS `product_d_infos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `doc_id` int(11) NOT NULL,
  `photographed` varchar(255) NOT NULL,
  `released` varchar(255) NOT NULL,
  `retained` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `product_d_infos`
--

INSERT INTO `product_d_infos` (`id`, `doc_id`, `photographed`, `released`, `retained`) VALUES
(1, 91, 'no', 'no', 'no'),
(2, 92, 'no', 'no', 'no'),
(6, 93, 'no', 'no', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `projectboards`
--

CREATE TABLE IF NOT EXISTS `projectboards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job_id` int(11) NOT NULL,
  `Include_on_project_board` varchar(255) NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `poy` varchar(11) NOT NULL DEFAULT '1980',
  `notes` text NOT NULL,
  `job_number` int(11) NOT NULL,
  `job_status` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `latitude` float NOT NULL,
  `longitude` float NOT NULL,
  `proposal_date` date NOT NULL,
  `contract_date` date NOT NULL,
  `competition_date` date NOT NULL,
  `active_start_date` date NOT NULL,
  `expiration_date` date NOT NULL,
  `completion_date` date NOT NULL,
  `new_expiration_date` date NOT NULL,
  `security_projected` float NOT NULL,
  `security_deployed` float NOT NULL,
  `logistics_projected` float NOT NULL,
  `logistics_deployed` float NOT NULL,
  `replacement_workers_projected` float NOT NULL,
  `replacement_workers_deployed` float NOT NULL,
  `dry_trailer_projected` float NOT NULL,
  `dry_trailer_deployed` float NOT NULL,
  `box_truck_projected` float NOT NULL,
  `box_truck_deployed` float NOT NULL,
  `box_reefer_projected` float NOT NULL,
  `box_reefer_deployed` float NOT NULL,
  `kitchen_trailer_projected` float NOT NULL,
  `kitchen_trailer_deployed` float NOT NULL,
  `refrigerated_trailer_projected` float NOT NULL,
  `refrigerated_trailer_deployed` float NOT NULL,
  `laundry_trailer_projected` float NOT NULL,
  `laundry_trailer_deployed` float NOT NULL,
  `shower_trailer_projected` float NOT NULL,
  `shower_trailer_deployed` float NOT NULL,
  `housing_trailer_projected` float NOT NULL,
  `housing_trailer_deployed` float NOT NULL,
  `dining_trailer_projected` float NOT NULL,
  `dining_trailer_deployed` float NOT NULL,
  `coach_trailer_projected` float NOT NULL,
  `coach_trailer_deployed` float NOT NULL,
  `school_trailer_projected` float NOT NULL,
  `school_trailer_deployed` float NOT NULL,
  `15pess_trailer_projected` float NOT NULL,
  `15pess_trailer_deployed` float NOT NULL,
  `5tone_trailer_projected` float NOT NULL,
  `5tone_trailer_deployed` float NOT NULL,
  `minivans_trailer_projected` float NOT NULL,
  `minivans_trailer_deployed` float NOT NULL,
  `suv_trailer_projected` float NOT NULL,
  `suv_trailer_deployed` float NOT NULL,
  `transport_trailer_projected` float NOT NULL,
  `transport_trailer_deployed` float NOT NULL,
  `reffer_trailer_projected` float NOT NULL,
  `reffer_trailer_deployed` float NOT NULL,
  `flatbed_trailer_projected` float NOT NULL,
  `flatbed_trailer_deployed` float NOT NULL,
  `cots_trailer_projected` float NOT NULL,
  `cots_trailer_deployed` float NOT NULL,
  `deployment_start_date` date NOT NULL,
  `tombstone_man_hours` float NOT NULL,
  `contact_info` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `projectboards`
--

INSERT INTO `projectboards` (`id`, `job_id`, `Include_on_project_board`, `client_name`, `poy`, `notes`, `job_number`, `job_status`, `city`, `state`, `latitude`, `longitude`, `proposal_date`, `contract_date`, `competition_date`, `active_start_date`, `expiration_date`, `completion_date`, `new_expiration_date`, `security_projected`, `security_deployed`, `logistics_projected`, `logistics_deployed`, `replacement_workers_projected`, `replacement_workers_deployed`, `dry_trailer_projected`, `dry_trailer_deployed`, `box_truck_projected`, `box_truck_deployed`, `box_reefer_projected`, `box_reefer_deployed`, `kitchen_trailer_projected`, `kitchen_trailer_deployed`, `refrigerated_trailer_projected`, `refrigerated_trailer_deployed`, `laundry_trailer_projected`, `laundry_trailer_deployed`, `shower_trailer_projected`, `shower_trailer_deployed`, `housing_trailer_projected`, `housing_trailer_deployed`, `dining_trailer_projected`, `dining_trailer_deployed`, `coach_trailer_projected`, `coach_trailer_deployed`, `school_trailer_projected`, `school_trailer_deployed`, `15pess_trailer_projected`, `15pess_trailer_deployed`, `5tone_trailer_projected`, `5tone_trailer_deployed`, `minivans_trailer_projected`, `minivans_trailer_deployed`, `suv_trailer_projected`, `suv_trailer_deployed`, `transport_trailer_projected`, `transport_trailer_deployed`, `reffer_trailer_projected`, `reffer_trailer_deployed`, `flatbed_trailer_projected`, `flatbed_trailer_deployed`, `cots_trailer_projected`, `cots_trailer_deployed`, `deployment_start_date`, `tombstone_man_hours`, `contact_info`) VALUES
(1, 1, 'Yes', 'job1111', '1967', 'adfadsfadf adfsasdfasdf', 12, 'On Project Board', 'miami', 'us', 25.789, -80.2264, '1970-01-14', '1970-01-22', '1970-01-02', '1970-01-21', '1970-01-23', '1970-01-21', '1970-01-01', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 7, 4, 6, 15, 15, 5, 5, 2, 2, 3, 4, 3, 6, 6, 5, 1, 2, 2, 33, '1970-01-09', 0, ''),
(2, 2, '', 'job2', '0', '', 0, '', '', '', 0, 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0, ''),
(3, 3, '', 'job 3', '0', '', 0, '', '', '', 0, 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0, ''),
(4, 4, '', 'adfadfadf', '0', '', 0, '', '', '', 0, 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0, ''),
(5, 5, '', 'qwqwe', '0', '', 0, '', '', '', 0, 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0, ''),
(6, 6, '', 'new', '0', '', 0, '', '', '', 0, 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0, ''),
(7, 7, '', 'new', '0', '', 0, '', '', '', 0, 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0, ''),
(8, 8, '', 'new', '0', '', 0, '', '', '', 0, 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0, ''),
(9, 9, '', 'project', '0', '', 0, '', '', '', 0, 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0, ''),
(10, 1000000, '', 'asd', '0', '', 0, '', '', '', 0, 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0, ''),
(11, 10, 'Yes', 'Special', '1234', '', 0, 'On Project Board', '', '', 0, 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0, ''),
(12, 11, '', 'statrus', '1980', '', 0, '', '', '', 0, 0, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0000-00-00', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `specialist_infos`
--

CREATE TABLE IF NOT EXISTS `specialist_infos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `doc_id` int(11) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `spec_id` varchar(255) NOT NULL,
  `int_by` varchar(255) NOT NULL,
  `int_id` varchar(255) NOT NULL,
  `witness` varchar(255) NOT NULL,
  `app_by` varchar(255) NOT NULL,
  `app_id` varchar(255) NOT NULL,
  `assisted_by` varchar(255) NOT NULL,
  `assisted_id` varchar(255) NOT NULL,
  `searched_by` varchar(255) NOT NULL,
  `witness_name` varchar(255) NOT NULL,
  `handcuffed` varchar(255) NOT NULL,
  `where` varchar(255) NOT NULL,
  `prosecuted` varchar(255) NOT NULL,
  `time_completed` varchar(255) NOT NULL,
  `time_began` varchar(255) NOT NULL,
  `others` varchar(255) NOT NULL,
  `approved_by` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `specialist_infos`
--

INSERT INTO `specialist_infos` (`id`, `doc_id`, `last_name`, `first_name`, `spec_id`, `int_by`, `int_id`, `witness`, `app_by`, `app_id`, `assisted_by`, `assisted_id`, `searched_by`, `witness_name`, `handcuffed`, `where`, `prosecuted`, `time_completed`, `time_began`, `others`, `approved_by`) VALUES
(1, 91, 'fgdfg', 'ewrfwer', 'sdf', 'sdfsd', 'fgfgh', 'fgfghfg', 'sdfsd', 'sdfsd', 'sdfsd', 'sdfsd', 'asdasds', 'dfsdfs', 'no', 'wqerwer', 'no', 'sdfsd', 'fgfgh', 'werwer', 'asdasda'),
(2, 92, 'fgdfg', 'ewrfwer', 'sdf', 'sdfsd', 'fgfgh', 'fgfghfg', 'sdfsd', 'sdfsd', 'sdfsd', 'sdfsd', 'asdasds', 'dfsdfs', 'no', 'wqerwer', 'no', 'sdfsd', 'fgfgh', 'werwer', 'asdasda'),
(6, 93, 'fgdfg1', 'ewrfwer1', 'sdf1', 'sdfsd1', 'fgfgh1', 'fgfghfg1', 'sdfsd1', 'sdfsd1', 'sdfsd1', 'sdfsd1', 'asdasds1', 'dfsdfs1', 'no', 'wqerwer1', 'no', 'sdfsd1', 'fgfgh1', 'werwer1', 'asdasda1');

-- --------------------------------------------------------

--
-- Table structure for table `spec_jobs`
--

CREATE TABLE IF NOT EXISTS `spec_jobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `document_type` varchar(255) NOT NULL,
  `dop` date NOT NULL,
  `author` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `desc` longtext NOT NULL,
  `doc` varchar(255) NOT NULL,
  `on_date` datetime NOT NULL,
  `addedBy` int(11) NOT NULL,
  `job_id` int(11) NOT NULL,
  `job_title` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `spec_jobs`
--

INSERT INTO `spec_jobs` (`id`, `document_type`, `dop`, `author`, `link`, `desc`, `doc`, `on_date`, `addedBy`, `job_id`, `job_title`) VALUES
(2, 'AFIMAC Intel', '2013-12-17', 'asdas dasd', '', '', '', '2013-12-24 12:42:50', 0, 10, 'Special'),
(3, 'AFIMAC Intel', '2013-12-17', 'asdas dasd', '', '', '85915_2013-12-24_12-43-22.jpg', '2013-12-24 12:43:22', 0, 10, 'Special'),
(4, 'AFIMAC Intel', '2013-12-17', 'asdas dasd', '', 'asda sdasdasd111111', '49949_2013-12-24_13-24-23.jpg', '2013-12-24 13:24:23', 0, 10, 'Special'),
(5, 'AFIMAC Intel', '2013-12-17', 'asdas dasd1', '', 'asda sdasdasd111111', '', '2013-12-24 13:54:38', 0, 10, 'Special'),
(6, 'News/Media', '2013-12-17', 'asdas dasd1', '', 'asda sdasdasd111111', '', '2013-12-24 13:54:53', 0, 10, 'Special'),
(7, 'AFIMAC Intel', '2014-01-01', 'test', '', 'adfadfadf', '40382_2014-01-03_16-20-21.jpg', '2014-01-03 16:20:21', 8, 10, 'Special'),
(8, 'AFIMAC Intel', '2014-01-01', 'adfadf', '', 'adfadfadf', '84231_2014-01-06_15-27-58.png', '2014-01-06 15:27:58', 8, 10, 'Special'),
(9, 'News/Media', '2014-01-06', 'asdasd', '', 'asdasd', '', '2014-01-07 17:11:47', 0, 10, 'Special'),
(10, 'News/Media', '2014-01-02', 'adfadf', '', 'adfadf', '', '2014-01-07 18:13:25', 8, 10, 'Special'),
(11, 'AFIMAC Intel', '2014-01-14', 'adfa', '', 'adfadfa', '37987_2014-01-14_17-15-47.png', '2014-01-14 17:15:47', 0, 10, 'Special'),
(12, 'AFIMAC Intel', '2014-01-14', 'adfa', '', 'adfadfa', '13762_2014-01-14_17-17-14.png', '2014-01-14 17:17:14', 0, 10, 'Special'),
(13, 'AFIMAC Intel', '2014-01-14', 'adfa', '', 'adfadfa', '79991_2014-01-14_17-18-58.png', '2014-01-14 17:18:58', 0, 10, 'Special'),
(14, 'AFIMAC Intel', '2014-01-14', 'adfa', '', 'adfadfa', '86223_2014-01-14_17-20-30.png', '2014-01-14 17:20:30', 0, 10, 'Special'),
(15, 'AFIMAC Intel', '2014-01-14', 'adfa', '', 'adfadfa', '15979_2014-01-14_17-20-58.png', '2014-01-14 17:20:58', 0, 10, 'Special'),
(16, 'AFIMAC Intel', '2014-01-14', 'adfa', '', 'adfadfa', '30494_2014-01-14_17-21-05.png', '2014-01-14 17:21:05', 0, 10, 'Special'),
(17, 'AFIMAC Intel', '2014-01-14', 'adfa', '', 'adfadfa', '41923_2014-01-14_17-21-08.png', '2014-01-14 17:21:08', 0, 10, 'Special'),
(18, 'AFIMAC Intel', '2014-01-14', 'adfa', '', 'adfadfa', '82476_2014-01-14_17-24-38.png', '2014-01-14 17:24:38', 0, 10, 'Special'),
(19, 'AFIMAC Intel', '2014-01-13', 'adfad', '', 'adfadf', '94883_2014-01-14_17-34-51.png', '2014-01-14 17:34:51', 0, 10, 'Special'),
(20, 'AFIMAC Intel', '2014-01-13', 'adfad', '', 'adfadf', '92260_2014-01-14_17-35-07.png', '2014-01-14 17:35:07', 0, 10, 'Special'),
(21, 'AFIMAC Intel', '2014-01-13', 'adfad', '', 'adfadf', '85410_2014-01-14_17-42-30.png', '2014-01-14 17:42:30', 0, 10, 'Special'),
(22, 'AFIMAC Intel', '2014-01-13', 'adfad', '', 'adfadf', '80573_2014-01-14_17-44-20.png', '2014-01-14 17:44:20', 0, 10, 'Special'),
(23, 'AFIMAC Intel', '2014-02-18', 'asdas dasd', '', 'adfadf', '', '2014-02-27 05:49:13', 0, 10, ''),
(24, 'AFIMAC Intel', '2014-02-18', 'asdas dasd', '', 'adfadf', '', '2014-02-27 05:53:20', 0, 10, 'Special');

-- --------------------------------------------------------

--
-- Table structure for table `store_infos`
--

CREATE TABLE IF NOT EXISTS `store_infos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `incident_title` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `day` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zip` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `ext` varchar(255) NOT NULL,
  `doc_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `store_infos`
--

INSERT INTO `store_infos` (`id`, `incident_title`, `date`, `day`, `time`, `name`, `address`, `state`, `zip`, `phone`, `ext`, `doc_id`) VALUES
(1, 'asdas', '0000-00-00', 'asdas', 'asdasd', 'asdasd', 'asdasd', 'asdasd', 'asdasd', 'asdasd', 'asdasd', 91),
(2, 'asdas', '0000-00-00', 'asdas', 'asdasd', 'asdasd', 'asdasd', 'asdasd', 'asdasd', 'asdasd', 'asdasd', 92),
(6, '', '0000-00-00', '', '', '', '', '', '', '', '', 93);

-- --------------------------------------------------------

--
-- Table structure for table `subject_infos`
--

CREATE TABLE IF NOT EXISTS `subject_infos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cash` varchar(255) NOT NULL,
  `weapons` varchar(255) NOT NULL,
  `weapon_desc` varchar(255) NOT NULL,
  `concealment` varchar(255) NOT NULL,
  `card_type` varchar(255) NOT NULL,
  `add_item` varchar(255) NOT NULL,
  `bankcards` varchar(255) NOT NULL,
  `doc_id` int(11) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `middle_name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `h_phone` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zip` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `dob` varchar(255) NOT NULL,
  `age` varchar(255) NOT NULL,
  `race` varchar(255) NOT NULL,
  `height` varchar(255) NOT NULL,
  `weight` varchar(255) NOT NULL,
  `hair` varchar(255) NOT NULL,
  `eyes` varchar(255) NOT NULL,
  `tattoos` varchar(255) NOT NULL,
  `scar` varchar(255) NOT NULL,
  `distinguishing` varchar(255) NOT NULL,
  `adult` varchar(255) NOT NULL,
  `parents` varchar(255) NOT NULL,
  `d_licence` varchar(255) NOT NULL,
  `v_licence` varchar(255) NOT NULL,
  `other_id` varchar(255) NOT NULL,
  `photograph` varchar(255) NOT NULL,
  `employed` varchar(255) NOT NULL,
  `occupation` varchar(255) NOT NULL,
  `clothing` varchar(255) NOT NULL,
  `comments` varchar(255) NOT NULL,
  `compliance` varchar(255) NOT NULL,
  `other_name` varchar(255) NOT NULL,
  `case_no` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `subject_infos`
--

INSERT INTO `subject_infos` (`id`, `cash`, `weapons`, `weapon_desc`, `concealment`, `card_type`, `add_item`, `bankcards`, `doc_id`, `last_name`, `first_name`, `middle_name`, `alias`, `h_phone`, `address`, `state`, `zip`, `gender`, `dob`, `age`, `race`, `height`, `weight`, `hair`, `eyes`, `tattoos`, `scar`, `distinguishing`, `adult`, `parents`, `d_licence`, `v_licence`, `other_id`, `photograph`, `employed`, `occupation`, `clothing`, `comments`, `compliance`, `other_name`, `case_no`) VALUES
(1, 'fgbhfgh', 'no', 'sdfsd', 'sdfsd', 'asdasda', 'dfgdfg', 'no', 91, 'asdasd', 'asdasd', 'asdasd', 'sdsf', 'qwqweqw', 'asdasd', 'asdasd', 'asdasd', 'female', 'asda', 'asdas', 'asdas', 'asdasd', 'asdasd', 'qwe', 'qweqw', 'qweqwe', 'qwe', 'reter', 'juvenile', 'sdfsdf', 'dfgdfgdf', 'werwer', 'vcvbcvsdf', 'sdfsdfsd', 'unemploted', 'asdasd', 'dfgdfgdfgdfg', 'asdasdasdasdasdasd', 'belligerent', 'asdasasdasdasdasasasdasdasdasb sdfsdf', 'asdasdasd'),
(2, 'fgbhfgh', 'no', 'sdfsd', 'sdfsd', 'asdasda', 'dfgdfg', 'no', 92, 'asdasd', 'asdasd', 'asdasd', 'sdsf', 'qwqweqw', 'asdasd', 'asdasd', 'asdasd', 'male', 'asda', 'asdas', 'asdas', 'asdasd', 'asdasd', 'qwe', 'qweqw', 'qweqwe', 'qwe', 'reter', 'adult', 'sdfsdf', 'dfgdfgdf', 'werwer', 'vcvbcvsdf', 'sdfsdfsd', 'emploted', 'asdasd', 'dfgdfgdfgdfg', 'asdasdasdasdasdasd', 'poor', 'asdasasdasdasdasasasdasdasdasb sdfsdf', 'asdasdasd'),
(6, 'fgbhfgh1', 'no', 'sdfsd1', 'sdfsd1', 'asdasda1', 'dfgdfg1', 'no', 93, 'asdasd1', 'asdasd1', 'asdasd1', 'sdsf1', 'qwqweqw1', 'asdasd1', 'asdasd1', 'asdasd1', 'female', 'asda1', 'asdas1', 'asdas1', 'asdasd1', 'asdasd1', 'qwe1', 'qweqw1', 'qweqwe1', 'qwe1', 'reter1', 'juvenile', 'sdfsdf1', 'dfgdfgdf1', 'werwer1', 'vcvbcvsdf1', 'sdfsdfsd1', 'unemployed', 'asdasd1', 'dfgdfgdfgdfg1', '1asdas asdpoakjs dpoask dpaskd ', 'belligerent', 'asdasasdasdasdasasasdasdasdasb sdfsdf1', 'asdasdasd1');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_avatar` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `picture` varchar(255) NOT NULL,
  `country` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name_avatar`, `email`, `password`, `picture`, `country`) VALUES
(2, 'Admin1', 'justdoit.2045@yahoo.com', 'f3f866ace1d3e4e6ab0aea76d0fdaef5', 'image10.jpg', 'canada');

-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

CREATE TABLE IF NOT EXISTS `videos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `document_id` int(11) NOT NULL,
  `video` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `videos`
--

INSERT INTO `videos` (`id`, `document_id`, `video`) VALUES
(1, 105, 'Evidence_2013-12-03_16-04-09.mp4'),
(2, 106, 'Evidence_Auther_2013-12-03_16-06-30.mp4');

-- --------------------------------------------------------

--
-- Table structure for table `youtubes`
--

CREATE TABLE IF NOT EXISTS `youtubes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `document_id` int(11) NOT NULL,
  `youtube` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `youtubes`
--

